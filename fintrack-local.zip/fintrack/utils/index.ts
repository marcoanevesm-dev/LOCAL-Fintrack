import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'
import { format, startOfMonth, endOfMonth, subMonths } from 'date-fns'
import { ptBR } from 'date-fns/locale'

// ============================================================
// TAILWIND
// ============================================================
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// ============================================================
// CURRENCY
// ============================================================
export function formatCurrency(value: number, currency = 'BRL'): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency,
    minimumFractionDigits: 2,
  }).format(value)
}

export function parseCurrency(value: string): number {
  const cleaned = value.replace(/[^\d,.-]/g, '').replace(',', '.')
  return parseFloat(cleaned) || 0
}

// ============================================================
// DATES
// ============================================================
export function formatDate(date: string | Date, pattern = 'dd/MM/yyyy'): string {
  const d = typeof date === 'string' ? new Date(date + 'T00:00:00') : date
  return format(d, pattern, { locale: ptBR })
}

export function formatDateRelative(date: string | Date): string {
  const d = typeof date === 'string' ? new Date(date) : date
  return format(d, "d 'de' MMMM 'de' yyyy", { locale: ptBR })
}

export function getCurrentMonthRange() {
  const now = new Date()
  return {
    start: format(startOfMonth(now), 'yyyy-MM-dd'),
    end: format(endOfMonth(now), 'yyyy-MM-dd'),
  }
}

export function getMonthRange(monthsAgo: number) {
  const date = subMonths(new Date(), monthsAgo)
  return {
    start: format(startOfMonth(date), 'yyyy-MM-dd'),
    end: format(endOfMonth(date), 'yyyy-MM-dd'),
    label: format(date, 'MMM/yyyy', { locale: ptBR }),
  }
}

export function getMonthName(month: number, year?: number): string {
  const date = new Date(year || new Date().getFullYear(), month - 1, 1)
  return format(date, 'MMMM', { locale: ptBR })
}

// ============================================================
// PERCENTAGE
// ============================================================
export function formatPercent(value: number, decimals = 1): string {
  return `${value.toFixed(decimals)}%`
}

export function calculatePercentage(value: number, total: number): number {
  if (total === 0) return 0
  return (value / total) * 100
}

// ============================================================
// COLORS
// ============================================================
export const CHART_COLORS = [
  '#6366f1', // indigo
  '#10b981', // emerald
  '#f59e0b', // amber
  '#ef4444', // red
  '#8b5cf6', // violet
  '#06b6d4', // cyan
  '#ec4899', // pink
  '#84cc16', // lime
  '#f97316', // orange
  '#14b8a6', // teal
]

export const CATEGORY_COLORS = [
  '#ef4444', '#f97316', '#f59e0b', '#eab308',
  '#84cc16', '#22c55e', '#10b981', '#14b8a6',
  '#06b6d4', '#0ea5e9', '#6366f1', '#8b5cf6',
  '#a855f7', '#ec4899', '#f43f5e', '#64748b',
]

export function getContrastColor(hexColor: string): string {
  const r = parseInt(hexColor.slice(1, 3), 16)
  const g = parseInt(hexColor.slice(3, 5), 16)
  const b = parseInt(hexColor.slice(5, 7), 16)
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255
  return luminance > 0.5 ? '#000000' : '#ffffff'
}

// ============================================================
// ACCOUNT / CATEGORY ICONS
// ============================================================
export const ACCOUNT_ICONS = [
  'wallet', 'credit-card', 'piggy-bank', 'building-2',
  'coins', 'landmark', 'briefcase', 'trending-up',
]

export const CATEGORY_ICONS = [
  'utensils', 'car', 'heart-pulse', 'home', 'graduation-cap',
  'trending-up', 'gamepad-2', 'monitor', 'shirt', 'plane',
  'zap', 'shopping-cart', 'dumbbell', 'music', 'dog',
  'coffee', 'gift', 'wrench', 'phone', 'tag',
]

// ============================================================
// INSIGHTS
// ============================================================
export function generateInsights(
  currentExpenses: number,
  previousExpenses: number,
  income: number,
  categorySpending: Array<{ name: string; amount: number; budget?: number }>
) {
  const insights = []
  const savingsRate = income > 0 ? ((income - currentExpenses) / income) * 100 : 0
  const expenseChange = previousExpenses > 0
    ? ((currentExpenses - previousExpenses) / previousExpenses) * 100
    : 0

  if (expenseChange > 15) {
    insights.push({
      type: 'warning' as const,
      title: 'Gastos em alta',
      description: `Seus gastos aumentaram ${Math.abs(expenseChange).toFixed(0)}% em relação ao mês anterior.`,
      value: expenseChange,
    })
  } else if (expenseChange < -10) {
    insights.push({
      type: 'success' as const,
      title: 'Gastos sob controle',
      description: `Você reduziu seus gastos em ${Math.abs(expenseChange).toFixed(0)}% comparado ao mês anterior.`,
      value: expenseChange,
    })
  }

  if (savingsRate >= 20) {
    insights.push({
      type: 'success' as const,
      title: 'Ótima taxa de poupança',
      description: `Você está economizando ${savingsRate.toFixed(0)}% da sua renda. Continue assim!`,
      value: savingsRate,
    })
  } else if (savingsRate < 10 && income > 0) {
    insights.push({
      type: 'warning' as const,
      title: 'Taxa de poupança baixa',
      description: `Você está economizando apenas ${savingsRate.toFixed(0)}% da renda. Tente chegar a 20%.`,
      value: savingsRate,
    })
  }

  categorySpending.forEach(({ name, amount, budget }) => {
    if (budget && amount > budget * 0.9) {
      insights.push({
        type: 'warning' as const,
        title: `Limite de ${name} quase atingido`,
        description: `Você usou ${((amount / budget) * 100).toFixed(0)}% do orçamento de ${name}.`,
        value: (amount / budget) * 100,
      })
    }
  })

  if (insights.length === 0) {
    insights.push({
      type: 'info' as const,
      title: 'Tudo em ordem',
      description: 'Suas finanças estão estáveis. Continue monitorando seus gastos.',
    })
  }

  return insights
}

// ============================================================
// GOAL
// ============================================================
export function estimateGoalMonths(
  target: number,
  current: number,
  monthlyContribution: number
): number {
  if (monthlyContribution <= 0) return Infinity
  return Math.ceil((target - current) / monthlyContribution)
}

// ============================================================
// MISC
// ============================================================
export function truncate(str: string, length = 30): string {
  if (str.length <= length) return str
  return str.slice(0, length) + '…'
}

export function getInitials(name: string): string {
  return name
    .split(' ')
    .slice(0, 2)
    .map(n => n[0])
    .join('')
    .toUpperCase()
}
