// ============================================================
// CORE DOMAIN TYPES
// ============================================================

export type UUID = string

export interface BaseEntity {
  id: UUID
  created_at: string
  updated_at: string
}

// ============================================================
// USER
// ============================================================

export interface UserProfile extends BaseEntity {
  user_id: UUID
  name: string
  email?: string
  avatar_url?: string
  currency: string
  locale: string
  monthly_income?: number
}

// ============================================================
// ACCOUNT
// ============================================================

export type AccountType = 'checking' | 'savings' | 'wallet' | 'credit_card' | 'investment'

export interface Account extends BaseEntity {
  user_id: UUID
  name: string
  type: AccountType
  balance: number
  color: string
  icon: string
  is_active: boolean
  bank_name?: string
}

// ============================================================
// CATEGORY
// ============================================================

export type CategoryType = 'income' | 'expense'

export interface Category extends BaseEntity {
  user_id: UUID
  name: string
  type: CategoryType
  color: string
  icon: string
  is_default: boolean
}

// ============================================================
// TRANSACTION
// ============================================================

export type TransactionType = 'income' | 'expense' | 'transfer'
export type TransactionStatus = 'pending' | 'completed' | 'cancelled'
export type PaymentMethod = 'cash' | 'debit' | 'credit' | 'pix' | 'transfer' | 'boleto'

export interface Transaction extends BaseEntity {
  user_id: UUID
  account_id: UUID
  category_id: UUID
  type: TransactionType
  amount: number
  description: string
  date: string
  status: TransactionStatus
  payment_method?: PaymentMethod
  notes?: string
  is_recurring: boolean
  recurrence_id?: UUID
  installment_id?: UUID
  installment_number?: number
  installment_total?: number
  // Joined fields
  account?: Account
  category?: Category
}

// ============================================================
// CREDIT CARD  (limit_amount aligns with DB column name)
// ============================================================

export interface CreditCard extends BaseEntity {
  user_id: UUID
  name: string
  bank_name: string
  limit_amount: number   // matches DB: credit_cards.limit_amount
  closing_day: number
  due_day: number
  color: string
  last_four_digits?: string
}

export interface CreditCardInstallment extends BaseEntity {
  credit_card_id: UUID
  user_id: UUID
  description: string
  total_amount: number
  installment_amount: number
  total_installments: number
  current_installment: number
  start_date: string
  category_id?: UUID
}

// ============================================================
// BUDGET
// ============================================================

export interface Budget extends BaseEntity {
  user_id: UUID
  category_id: UUID
  amount: number
  month: number
  year: number
  spent: number          // computed client-side
  alert_threshold: number
  category?: Category
}

// ============================================================
// GOAL
// ============================================================

export type GoalStatus = 'active' | 'completed' | 'paused' | 'cancelled'

export interface Goal extends BaseEntity {
  user_id: UUID
  name: string
  description?: string
  target_amount: number
  current_amount: number
  target_date?: string
  color: string
  icon: string
  status: GoalStatus
  monthly_contribution?: number
}

// ============================================================
// INVESTMENT
// ============================================================

export type InvestmentType = 'stocks' | 'fii' | 'treasury' | 'cdb' | 'crypto' | 'other'

export interface Investment extends BaseEntity {
  user_id: UUID
  name: string
  ticker?: string
  type: InvestmentType
  quantity: number
  average_price: number
  current_price: number
  invested_amount: number
  current_value: number
  profitability: number
  broker?: string
}

// ============================================================
// NOTIFICATION
// ============================================================

export type NotificationType =
  | 'bill_due'
  | 'credit_card_due'
  | 'goal_reached'
  | 'budget_alert'
  | 'system'

export interface Notification extends BaseEntity {
  user_id: UUID
  type: NotificationType
  title: string
  message: string
  is_read: boolean
  action_url?: string
  related_id?: UUID
}

// ============================================================
// DASHBOARD / ANALYTICS
// ============================================================

export interface DashboardSummary {
  total_balance: number
  monthly_income: number
  monthly_expenses: number
  monthly_savings: number
  savings_rate: number
}

export interface MonthlyEvolution {
  month: string
  income: number
  expenses: number
  savings: number
}

export interface CategorySpending {
  category_id: UUID
  category_name: string
  color: string
  amount: number
  percentage: number
}

export interface FinancialInsight {
  type: 'warning' | 'success' | 'info' | 'tip'
  title: string
  description: string
  value?: number
  comparison?: number
}

// ============================================================
// FORM DATA
// ============================================================

export interface TransactionFormData {
  type: TransactionType
  amount: number
  description: string
  date: string
  account_id: UUID
  category_id: UUID
  payment_method?: PaymentMethod
  notes?: string
  is_recurring?: boolean
  installments?: number
}

export interface AccountFormData {
  name: string
  type: AccountType
  balance: number
  color: string
  icon: string
  bank_name?: string
}

export interface CategoryFormData {
  name: string
  type: CategoryType
  color: string
  icon: string
}

export interface GoalFormData {
  name: string
  description?: string
  target_amount: number
  current_amount: number
  target_date?: string
  color: string
  icon: string
  monthly_contribution?: number
}

export interface BudgetFormData {
  category_id: UUID
  amount: number
  month: number
  year: number
  alert_threshold: number
}

// CreditCardFormData uses limit_amount to match DB + service
export interface CreditCardFormData {
  name: string
  bank_name: string
  limit_amount: number
  closing_day: number
  due_day: number
  color: string
  last_four_digits?: string
}

// ============================================================
// FILTERS
// ============================================================

export interface TransactionFilters {
  type?: TransactionType
  category_id?: UUID
  account_id?: UUID
  start_date?: string
  end_date?: string
  min_amount?: number
  max_amount?: number
  search?: string
  status?: TransactionStatus
}

export interface DateRange {
  from: Date
  to: Date
}

// ============================================================
// API RESPONSES
// ============================================================

export interface ApiResponse<T> {
  data: T | null
  error: string | null
}

export interface PaginatedResponse<T> {
  data: T[]
  count: number
  page: number
  per_page: number
}
