/**
 * This file mirrors `database/schema.sql` so the Supabase client is
 * fully typed without needing the Supabase CLI.
 *
 * To regenerate from your live project instead (recommended once your
 * schema evolves), run:
 *
 *   npx supabase gen types typescript --project-id YOUR_PROJECT_ID > types/supabase.ts
 */

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          user_id: string
          name: string
          avatar_url: string | null
          currency: string
          locale: string
          monthly_income: number | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          name?: string
          avatar_url?: string | null
          currency?: string
          locale?: string
          monthly_income?: number | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          name?: string
          avatar_url?: string | null
          currency?: string
          locale?: string
          monthly_income?: number | null
          created_at?: string
          updated_at?: string
        }
        Relationships: []
      }
      accounts: {
        Row: {
          id: string
          user_id: string
          name: string
          type: string
          balance: number
          color: string
          icon: string
          bank_name: string | null
          is_active: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          name: string
          type: string
          balance?: number
          color?: string
          icon?: string
          bank_name?: string | null
          is_active?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          name?: string
          type?: string
          balance?: number
          color?: string
          icon?: string
          bank_name?: string | null
          is_active?: boolean
          created_at?: string
          updated_at?: string
        }
        Relationships: []
      }
      categories: {
        Row: {
          id: string
          user_id: string
          name: string
          type: string
          color: string
          icon: string
          is_default: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          name: string
          type: string
          color?: string
          icon?: string
          is_default?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          name?: string
          type?: string
          color?: string
          icon?: string
          is_default?: boolean
          created_at?: string
          updated_at?: string
        }
        Relationships: []
      }
      transactions: {
        Row: {
          id: string
          user_id: string
          account_id: string
          category_id: string
          type: string
          amount: number
          description: string
          date: string
          status: string
          payment_method: string | null
          notes: string | null
          is_recurring: boolean
          recurrence_id: string | null
          installment_id: string | null
          installment_number: number | null
          installment_total: number | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          account_id: string
          category_id: string
          type: string
          amount: number
          description: string
          date: string
          status?: string
          payment_method?: string | null
          notes?: string | null
          is_recurring?: boolean
          recurrence_id?: string | null
          installment_id?: string | null
          installment_number?: number | null
          installment_total?: number | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          account_id?: string
          category_id?: string
          type?: string
          amount?: number
          description?: string
          date?: string
          status?: string
          payment_method?: string | null
          notes?: string | null
          is_recurring?: boolean
          recurrence_id?: string | null
          installment_id?: string | null
          installment_number?: number | null
          installment_total?: number | null
          created_at?: string
          updated_at?: string
        }
        Relationships: []
      }
      credit_cards: {
        Row: {
          id: string
          user_id: string
          name: string
          bank_name: string
          limit_amount: number
          closing_day: number
          due_day: number
          color: string
          last_four_digits: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          name: string
          bank_name?: string
          limit_amount?: number
          closing_day: number
          due_day: number
          color?: string
          last_four_digits?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          name?: string
          bank_name?: string
          limit_amount?: number
          closing_day?: number
          due_day?: number
          color?: string
          last_four_digits?: string | null
          created_at?: string
          updated_at?: string
        }
        Relationships: []
      }
      credit_card_installments: {
        Row: {
          id: string
          credit_card_id: string
          user_id: string
          description: string
          total_amount: number
          installment_amount: number
          total_installments: number
          current_installment: number
          start_date: string
          category_id: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          credit_card_id: string
          user_id: string
          description: string
          total_amount: number
          installment_amount: number
          total_installments: number
          current_installment?: number
          start_date: string
          category_id?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          credit_card_id?: string
          user_id?: string
          description?: string
          total_amount?: number
          installment_amount?: number
          total_installments?: number
          current_installment?: number
          start_date?: string
          category_id?: string | null
          created_at?: string
          updated_at?: string
        }
        Relationships: []
      }
      budgets: {
        Row: {
          id: string
          user_id: string
          category_id: string
          amount: number
          month: number
          year: number
          alert_threshold: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          category_id: string
          amount: number
          month: number
          year: number
          alert_threshold?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          category_id?: string
          amount?: number
          month?: number
          year?: number
          alert_threshold?: number
          created_at?: string
          updated_at?: string
        }
        Relationships: []
      }
      goals: {
        Row: {
          id: string
          user_id: string
          name: string
          description: string | null
          target_amount: number
          current_amount: number
          target_date: string | null
          color: string
          icon: string
          status: string
          monthly_contribution: number | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          name: string
          description?: string | null
          target_amount: number
          current_amount?: number
          target_date?: string | null
          color?: string
          icon?: string
          status?: string
          monthly_contribution?: number | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          name?: string
          description?: string | null
          target_amount?: number
          current_amount?: number
          target_date?: string | null
          color?: string
          icon?: string
          status?: string
          monthly_contribution?: number | null
          created_at?: string
          updated_at?: string
        }
        Relationships: []
      }
      investments: {
        Row: {
          id: string
          user_id: string
          name: string
          ticker: string | null
          type: string
          quantity: number
          average_price: number
          current_price: number
          invested_amount: number
          current_value: number
          profitability: number
          broker: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          name: string
          ticker?: string | null
          type: string
          quantity?: number
          average_price?: number
          current_price?: number
          invested_amount?: number
          current_value?: number
          profitability?: number
          broker?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          name?: string
          ticker?: string | null
          type?: string
          quantity?: number
          average_price?: number
          current_price?: number
          invested_amount?: number
          current_value?: number
          profitability?: number
          broker?: string | null
          created_at?: string
          updated_at?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          id: string
          user_id: string
          type: string
          title: string
          message: string
          is_read: boolean
          action_url: string | null
          related_id: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          type: string
          title: string
          message: string
          is_read?: boolean
          action_url?: string | null
          related_id?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          type?: string
          title?: string
          message?: string
          is_read?: boolean
          action_url?: string | null
          related_id?: string | null
          created_at?: string
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}
