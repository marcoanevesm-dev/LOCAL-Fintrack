# 💰 FinTrack — Controle Financeiro Pessoal

> Plataforma completa de finanças pessoais com dashboard visual, metas, orçamentos, cartões de crédito e inteligência financeira automática.

![Next.js](https://img.shields.io/badge/Next.js-14-black?logo=next.js)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue?logo=typescript)
![Supabase](https://img.shields.io/badge/Supabase-PostgreSQL-green?logo=supabase)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-CSS-38bdf8?logo=tailwindcss)

---

## ✨ Funcionalidades

| Módulo | Descrição |
|---|---|
| 🔐 Autenticação | Cadastro, login, recuperação de senha via Supabase Auth |
| 📊 Dashboard | Saldo, receitas, despesas, economia, gráficos e insights automáticos |
| 💸 Transações | CRUD completo com parcelamento, filtros e categorias |
| 🏦 Contas | Corrente, poupança, carteira, investimento com saldo individual |
| 💳 Cartões | Limite, fatura do ciclo atual, alertas de uso |
| 🎯 Metas | Progresso visual, contribuições e tempo estimado |
| 📋 Orçamentos | Limite por categoria/mês com alertas configuráveis |
| 📈 Investimentos | Ações, FIIs, Tesouro, CDB, Cripto com rentabilidade |
| 📑 Relatórios | Mensal / Trimestral / Anual com exportação CSV e JSON |
| 🧠 Inteligência | Detecção automática de padrões e sugestões de economia |

---

## 🛠 Stack

- **Frontend:** React 18 + TypeScript
- **Framework:** Next.js 14 (App Router)
- **Estilização:** Tailwind CSS + shadcn/ui
- **Backend & Auth:** Supabase (PostgreSQL + Auth + RLS)
- **Gráficos:** Recharts
- **Estado:** Zustand (com persist)
- **Formulários:** React Hook Form + Zod
- **Deploy:** Vercel

---

## 🚀 Início rápido

### 1. Clone o repositório

```bash
git clone https://github.com/seu-usuario/fintrack.git
cd fintrack
```

### 2. Instale as dependências

```bash
npm install
# ou
pnpm install
```

### 3. Configure o Supabase

#### 3a. Crie um projeto em [supabase.com](https://supabase.com)

#### 3b. Execute o schema SQL

No **SQL Editor** do seu projeto Supabase, execute o conteúdo completo de:

```
database/schema.sql
```

Isso criará todas as tabelas, índices, políticas de Row Level Security e triggers.

#### 3c. Configure as variáveis de ambiente

```bash
cp .env.example .env.local
```

Preencha `.env.local` com os valores do seu projeto Supabase:

```env
NEXT_PUBLIC_SUPABASE_URL=https://xxxxxxxxxxxxxxxxxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

Os valores estão em: **Supabase Dashboard → Settings → API**

### 4. Execute localmente

```bash
npm run dev
```

Acesse [http://localhost:3000](http://localhost:3000)

---

## 🗄 Estrutura do banco de dados

```
profiles            → extensão do auth.users (nome, moeda, renda)
accounts            → contas do usuário (corrente, poupança, etc.)
categories          → categorias de receita/despesa (com seed automático)
transactions        → todas as movimentações financeiras
credit_cards        → cartões de crédito cadastrados
credit_card_installments → controle de parcelamentos
budgets             → orçamentos mensais por categoria
goals               → metas financeiras com progresso
investments         → portfólio de investimentos
notifications       → notificações e alertas
```

Toda tabela usa **Row Level Security (RLS)** — cada usuário só acessa seus próprios dados.

---

## 📁 Estrutura do projeto

```
fintrack/
├── app/
│   ├── auth/
│   │   ├── login/page.tsx
│   │   ├── register/page.tsx
│   │   └── reset-password/page.tsx
│   ├── dashboard/page.tsx
│   ├── transactions/page.tsx
│   ├── accounts/page.tsx
│   ├── credit-cards/page.tsx
│   ├── budgets/page.tsx
│   ├── goals/page.tsx
│   ├── investments/page.tsx
│   ├── reports/page.tsx
│   ├── settings/page.tsx
│   ├── globals.css
│   └── layout.tsx
├── components/
│   ├── ui/                  ← shadcn/ui components
│   ├── layout/              ← Sidebar, AppLayout, ThemeProvider
│   ├── dashboard/           ← StatCard, Charts, InsightsPanel...
│   ├── transactions/        ← TransactionDialog, DeleteDialog
│   ├── accounts/            ← AccountDialog
│   ├── credit-cards/        ← CreditCardDialog
│   ├── goals/               ← GoalDialog, ContributeDialog
│   ├── budgets/             ← BudgetDialog
│   └── investments/         ← InvestmentDialog
├── hooks/
│   └── index.ts             ← useAuth, useAccounts, useDashboard...
├── services/
│   ├── accounts.ts
│   ├── categories.ts
│   ├── transactions.ts
│   ├── credit-cards.ts
│   ├── budgets.ts
│   ├── goals.ts
│   └── investments.ts
├── store/
│   └── index.ts             ← Zustand stores
├── types/
│   ├── index.ts             ← Domain types
│   └── supabase.ts          ← DB types (gerar via CLI)
├── utils/
│   └── index.ts             ← formatCurrency, formatDate, insights...
├── database/
│   └── schema.sql           ← Schema PostgreSQL completo
├── middleware.ts             ← Proteção de rotas
└── .env.example
```

---

## ☁️ Deploy na Vercel

### 1. Push para o GitHub

```bash
git init
git add .
git commit -m "feat: initial commit"
git remote add origin https://github.com/seu-usuario/fintrack.git
git push -u origin main
```

### 2. Importe na Vercel

1. Acesse [vercel.com/new](https://vercel.com/new)
2. Conecte o repositório GitHub
3. Adicione as variáveis de ambiente:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `NEXT_PUBLIC_APP_URL` (URL da Vercel após o deploy)
4. Clique em **Deploy**

### 3. Configure o redirect de e-mail no Supabase

Em **Supabase → Authentication → URL Configuration**, adicione:

```
Site URL: https://seu-projeto.vercel.app
Redirect URLs: https://seu-projeto.vercel.app/**
```

---

## 🔑 Gerar tipos TypeScript do Supabase

Para ter tipagem forte do banco de dados, execute após criar as tabelas:

```bash
npx supabase login
npx supabase gen types typescript --project-id SEU_PROJECT_ID > types/supabase.ts
```

Substitua o conteúdo do stub `types/supabase.ts` pelo arquivo gerado.

---

## 🔐 Segurança

- **Row Level Security (RLS)** ativo em todas as tabelas
- Cada usuário acessa **somente seus próprios dados**
- Autenticação gerida pelo **Supabase Auth** (JWT + refresh tokens)
- Senhas nunca armazenadas no app — tratadas pelo Supabase
- Middleware Next.js protege todas as rotas privadas

---

## 📦 Scripts disponíveis

```bash
npm run dev          # Inicia o servidor de desenvolvimento
npm run build        # Build de produção
npm run start        # Inicia o servidor de produção
npm run lint         # ESLint
npm run type-check   # Verificação TypeScript sem compilar
```

---

## 🤝 Integração com Lovable

Este projeto foi estruturado para ser compatível com o Lovable:

1. Faça o push para o GitHub
2. No Lovable, conecte o repositório via **"Import from GitHub"**
3. As variáveis de ambiente do Supabase devem ser configuradas nas Settings do Lovable
4. O Lovable detectará automaticamente o projeto Next.js

---

## 📝 Licença

MIT © FinTrack
