import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type {
  Account, Category, Transaction, CreditCard,
  Budget, Goal, Investment, Notification,
  UserProfile, DashboardSummary, TransactionFilters,
} from '@/types'

// ============================================================
// AUTH STORE
// ============================================================
interface AuthState {
  user: UserProfile | null
  isLoading: boolean
  setUser: (user: UserProfile | null) => void
  setLoading: (loading: boolean) => void
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isLoading: true,
      setUser: (user) => set({ user }),
      setLoading: (isLoading) => set({ isLoading }),
    }),
    { name: 'auth-storage' }
  )
)

// ============================================================
// TRANSACTIONS STORE
// ============================================================
interface TransactionState {
  transactions: Transaction[]
  filters: TransactionFilters
  isLoading: boolean
  setTransactions: (transactions: Transaction[]) => void
  addTransaction: (transaction: Transaction) => void
  updateTransaction: (id: string, data: Partial<Transaction>) => void
  removeTransaction: (id: string) => void
  setFilters: (filters: Partial<TransactionFilters>) => void
  clearFilters: () => void
  setLoading: (loading: boolean) => void
}

export const useTransactionStore = create<TransactionState>((set) => ({
  transactions: [],
  filters: {},
  isLoading: false,
  setTransactions: (transactions) => set({ transactions }),
  addTransaction: (transaction) =>
    set((state) => ({ transactions: [transaction, ...state.transactions] })),
  updateTransaction: (id, data) =>
    set((state) => ({
      transactions: state.transactions.map((t) =>
        t.id === id ? { ...t, ...data } : t
      ),
    })),
  removeTransaction: (id) =>
    set((state) => ({
      transactions: state.transactions.filter((t) => t.id !== id),
    })),
  setFilters: (filters) =>
    set((state) => ({ filters: { ...state.filters, ...filters } })),
  clearFilters: () => set({ filters: {} }),
  setLoading: (isLoading) => set({ isLoading }),
}))

// ============================================================
// ACCOUNTS STORE
// ============================================================
interface AccountState {
  accounts: Account[]
  isLoading: boolean
  setAccounts: (accounts: Account[]) => void
  addAccount: (account: Account) => void
  updateAccount: (id: string, data: Partial<Account>) => void
  removeAccount: (id: string) => void
  setLoading: (loading: boolean) => void
}

export const useAccountStore = create<AccountState>((set) => ({
  accounts: [],
  isLoading: false,
  setAccounts: (accounts) => set({ accounts }),
  addAccount: (account) =>
    set((state) => ({ accounts: [...state.accounts, account] })),
  updateAccount: (id, data) =>
    set((state) => ({
      accounts: state.accounts.map((a) =>
        a.id === id ? { ...a, ...data } : a
      ),
    })),
  removeAccount: (id) =>
    set((state) => ({
      accounts: state.accounts.filter((a) => a.id !== id),
    })),
  setLoading: (isLoading) => set({ isLoading }),
}))

// ============================================================
// CATEGORIES STORE
// ============================================================
interface CategoryState {
  categories: Category[]
  isLoading: boolean
  setCategories: (categories: Category[]) => void
  addCategory: (category: Category) => void
  updateCategory: (id: string, data: Partial<Category>) => void
  removeCategory: (id: string) => void
  setLoading: (loading: boolean) => void
}

export const useCategoryStore = create<CategoryState>((set) => ({
  categories: [],
  isLoading: false,
  setCategories: (categories) => set({ categories }),
  addCategory: (category) =>
    set((state) => ({ categories: [...state.categories, category] })),
  updateCategory: (id, data) =>
    set((state) => ({
      categories: state.categories.map((c) =>
        c.id === id ? { ...c, ...data } : c
      ),
    })),
  removeCategory: (id) =>
    set((state) => ({
      categories: state.categories.filter((c) => c.id !== id),
    })),
  setLoading: (isLoading) => set({ isLoading }),
}))

// ============================================================
// GOALS STORE
// ============================================================
interface GoalState {
  goals: Goal[]
  isLoading: boolean
  setGoals: (goals: Goal[]) => void
  addGoal: (goal: Goal) => void
  updateGoal: (id: string, data: Partial<Goal>) => void
  removeGoal: (id: string) => void
  setLoading: (loading: boolean) => void
}

export const useGoalStore = create<GoalState>((set) => ({
  goals: [],
  isLoading: false,
  setGoals: (goals) => set({ goals }),
  addGoal: (goal) =>
    set((state) => ({ goals: [...state.goals, goal] })),
  updateGoal: (id, data) =>
    set((state) => ({
      goals: state.goals.map((g) => (g.id === id ? { ...g, ...data } : g)),
    })),
  removeGoal: (id) =>
    set((state) => ({ goals: state.goals.filter((g) => g.id !== id) })),
  setLoading: (isLoading) => set({ isLoading }),
}))

// ============================================================
// DASHBOARD STORE
// ============================================================
interface DashboardState {
  summary: DashboardSummary | null
  isLoading: boolean
  setSummary: (summary: DashboardSummary) => void
  setLoading: (loading: boolean) => void
}

export const useDashboardStore = create<DashboardState>((set) => ({
  summary: null,
  isLoading: false,
  setSummary: (summary) => set({ summary }),
  setLoading: (isLoading) => set({ isLoading }),
}))

// ============================================================
// UI STORE
// ============================================================
interface UIState {
  sidebarOpen: boolean
  showBalances: boolean
  toggleSidebar: () => void
  setSidebarOpen: (open: boolean) => void
  toggleBalances: () => void
}

export const useUIStore = create<UIState>()(
  persist(
    (set) => ({
      sidebarOpen: true,
      showBalances: true,
      toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),
      setSidebarOpen: (sidebarOpen) => set({ sidebarOpen }),
      toggleBalances: () => set((s) => ({ showBalances: !s.showBalances })),
    }),
    { name: 'ui-storage' }
  )
)

// ============================================================
// NOTIFICATIONS STORE
// ============================================================
interface NotificationState {
  notifications: Notification[]
  unreadCount: number
  setNotifications: (n: Notification[]) => void
  markAsRead: (id: string) => void
  markAllAsRead: () => void
}

export const useNotificationStore = create<NotificationState>((set) => ({
  notifications: [],
  unreadCount: 0,
  setNotifications: (notifications) =>
    set({ notifications, unreadCount: notifications.filter((n) => !n.is_read).length }),
  markAsRead: (id) =>
    set((state) => ({
      notifications: state.notifications.map((n) =>
        n.id === id ? { ...n, is_read: true } : n
      ),
      unreadCount: Math.max(0, state.unreadCount - 1),
    })),
  markAllAsRead: () =>
    set((state) => ({
      notifications: state.notifications.map((n) => ({ ...n, is_read: true })),
      unreadCount: 0,
    })),
}))
