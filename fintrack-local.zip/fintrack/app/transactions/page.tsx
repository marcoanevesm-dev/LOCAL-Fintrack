'use client'

import { useState } from 'react'
import { Plus, Search } from 'lucide-react'
import { useTransactions, useCategories, useAccounts } from '@/hooks'
import { useAuthStore, useTransactionStore } from '@/store'
import { deleteTransaction } from '@/services/transactions'
import { formatCurrency, formatDate, getCurrentMonthRange } from '@/utils'
import { cn } from '@/utils'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { TransactionDialog } from '@/components/transactions/TransactionDialog'
import { TransactionDeleteDialog } from '@/components/transactions/TransactionDeleteDialog'
import type { Transaction } from '@/types'

export default function TransactionsPage() {
  const { user } = useAuthStore()
  const [open, setOpen] = useState(false)
  const [editTx, setEditTx] = useState<Transaction | null>(null)
  const [deleteTx, setDeleteTx] = useState<Transaction | null>(null)
  const [search, setSearch] = useState('')
  const [typeFilter, setTypeFilter] = useState<string>('all')
  const { removeTransaction } = useTransactionStore()

  const { start, end } = getCurrentMonthRange()
  const { transactions, isLoading, refetch } = useTransactions({ start_date: start, end_date: end })

  const filtered = transactions.filter((tx) => {
    if (typeFilter !== 'all' && tx.type !== typeFilter) return false
    if (search && !tx.description.toLowerCase().includes(search.toLowerCase())) return false
    return true
  })

  const handleDelete = async () => {
    if (!deleteTx || !user) return
    await deleteTransaction(deleteTx.id, user.user_id)
    removeTransaction(deleteTx.id)
    setDeleteTx(null)
  }

  const totalIncome = filtered
    .filter((t) => t.type === 'income')
    .reduce((s, t) => s + t.amount, 0)
  const totalExpense = filtered
    .filter((t) => t.type === 'expense')
    .reduce((s, t) => s + t.amount, 0)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold">Transações</h1>
          <p className="text-muted-foreground text-sm mt-1">
            {filtered.length} transações este mês
          </p>
        </div>
        <Button onClick={() => { setEditTx(null); setOpen(true) }} className="gap-2">
          <Plus className="h-4 w-4" />
          Nova transação
        </Button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 gap-4">
        <div className="ft-card p-4 bg-emerald-50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800/40">
          <p className="text-xs text-muted-foreground">Receitas</p>
          <p className="text-lg font-bold text-emerald-600 number-display">+{formatCurrency(totalIncome)}</p>
        </div>
        <div className="ft-card p-4 bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-800/40">
          <p className="text-xs text-muted-foreground">Despesas</p>
          <p className="text-lg font-bold text-red-600 number-display">-{formatCurrency(totalExpense)}</p>
        </div>
      </div>

      {/* Filters */}
      <div className="ft-card p-4">
        <div className="flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar transação..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Tipo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="income">Receitas</SelectItem>
              <SelectItem value="expense">Despesas</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* List */}
      <div className="ft-card">
        {isLoading ? (
          <div className="p-8 text-center text-muted-foreground text-sm">Carregando...</div>
        ) : filtered.length === 0 ? (
          <div className="p-8 text-center">
            <p className="text-muted-foreground">Nenhuma transação encontrada</p>
            <Button variant="outline" className="mt-4" onClick={() => { setEditTx(null); setOpen(true) }}>
              <Plus className="h-4 w-4 mr-2" />
              Adicionar transação
            </Button>
          </div>
        ) : (
          <div className="divide-y divide-border">
            {filtered.map((tx) => (
              <div
                key={tx.id}
                className="flex items-center gap-4 px-6 py-4 hover:bg-accent/30 transition-colors group"
              >
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                  style={{
                    background: (tx.category?.color ?? '#6366f1') + '22',
                    border: `1.5px solid ${(tx.category?.color ?? '#6366f1')}44`,
                  }}
                >
                  <span
                    className="w-3 h-3 rounded-full"
                    style={{ background: tx.category?.color ?? '#6366f1' }}
                  />
                </div>

                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm">{tx.description}</p>
                  <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                    <span className="text-xs text-muted-foreground">{tx.category?.name}</span>
                    <span className="text-xs text-muted-foreground">·</span>
                    <span className="text-xs text-muted-foreground">{tx.account?.name}</span>
                    <span className="text-xs text-muted-foreground">·</span>
                    <span className="text-xs text-muted-foreground">{formatDate(tx.date)}</span>
                  </div>
                </div>

                {tx.installment_total && (
                  <Badge variant="outline" className="text-[10px] shrink-0">
                    {tx.installment_number}/{tx.installment_total}x
                  </Badge>
                )}

                <div className="text-right shrink-0">
                  <p className={cn(
                    'text-sm font-semibold number-display',
                    tx.type === 'income'
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : 'text-red-600 dark:text-red-400'
                  )}>
                    {tx.type === 'income' ? '+' : '-'}{formatCurrency(tx.amount)}
                  </p>
                  <div className="flex gap-1 mt-1 justify-end opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 text-xs px-2"
                      onClick={() => { setEditTx(tx); setOpen(true) }}
                    >
                      Editar
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 text-xs px-2 text-destructive hover:text-destructive"
                      onClick={() => setDeleteTx(tx)}
                    >
                      Excluir
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <TransactionDialog
        open={open}
        onClose={() => setOpen(false)}
        transaction={editTx}
        onSuccess={() => { setOpen(false); refetch() }}
      />

      <TransactionDeleteDialog
        open={!!deleteTx}
        onClose={() => setDeleteTx(null)}
        onConfirm={handleDelete}
        description={deleteTx?.description ?? ''}
      />
    </div>
  )
}
