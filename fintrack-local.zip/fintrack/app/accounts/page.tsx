'use client'

import { useState } from 'react'
import { Plus, Wallet, CreditCard, PiggyBank, TrendingUp, Banknote } from 'lucide-react'
import { useAccounts } from '@/hooks'
import { useAuthStore, useAccountStore } from '@/store'
import { createAccount, updateAccount, deleteAccount, getTotalBalance } from '@/services/accounts'
import { formatCurrency } from '@/utils'
import { cn } from '@/utils'
import { Button } from '@/components/ui/button'
import { useToast } from '@/components/ui/use-toast'
import { AccountDialog } from '@/components/accounts/AccountDialog'
import type { Account, AccountFormData, AccountType } from '@/types'

const ACCOUNT_TYPE_CONFIG: Record<AccountType, { label: string; icon: any; color: string }> = {
  checking: { label: 'Conta Corrente', icon: Wallet, color: 'text-indigo-600' },
  savings: { label: 'Poupança', icon: PiggyBank, color: 'text-emerald-600' },
  wallet: { label: 'Carteira', icon: Banknote, color: 'text-amber-600' },
  credit_card: { label: 'Cartão de Crédito', icon: CreditCard, color: 'text-red-600' },
  investment: { label: 'Investimento', icon: TrendingUp, color: 'text-violet-600' },
}

export default function AccountsPage() {
  const { user } = useAuthStore()
  const { accounts, isLoading, refetch } = useAccounts()
  const { addAccount, updateAccount: updateStore, removeAccount } = useAccountStore()
  const { toast } = useToast()
  const [open, setOpen] = useState(false)
  const [editAccount, setEditAccount] = useState<Account | null>(null)

  const totalBalance = getTotalBalance(accounts)

  const handleSave = async (data: AccountFormData) => {
    if (!user) return
    try {
      if (editAccount) {
        const updated = await updateAccount(editAccount.id, user.user_id, data)
        updateStore(editAccount.id, updated)
        toast({ title: 'Conta atualizada' })
      } else {
        const created = await createAccount(user.user_id, data)
        addAccount(created)
        toast({ title: 'Conta criada' })
      }
      setOpen(false)
      setEditAccount(null)
    } catch (e: any) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' })
    }
  }

  const handleDelete = async (acc: Account) => {
    if (!user) return
    try {
      await deleteAccount(acc.id, user.user_id)
      removeAccount(acc.id)
      toast({ title: 'Conta removida' })
    } catch (e: any) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' })
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold">Contas</h1>
          <p className="text-muted-foreground text-sm mt-1">
            {accounts.length} conta{accounts.length !== 1 ? 's' : ''} cadastrada{accounts.length !== 1 ? 's' : ''}
          </p>
        </div>
        <Button onClick={() => { setEditAccount(null); setOpen(true) }} className="gap-2">
          <Plus className="h-4 w-4" />
          Nova conta
        </Button>
      </div>

      {/* Total balance hero */}
      <div className="ft-card p-6 bg-gradient-to-br from-indigo-600 to-violet-700 text-white border-0">
        <p className="text-sm text-indigo-200 font-medium">Patrimônio total</p>
        <p className="text-4xl font-bold mt-1 number-display">{formatCurrency(totalBalance)}</p>
        <p className="text-indigo-200 text-sm mt-2">Soma de todas as contas (exceto cartão de crédito)</p>
      </div>

      {/* Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="ft-card p-6 h-36 animate-pulse bg-muted" />
          ))}
        </div>
      ) : accounts.length === 0 ? (
        <div className="ft-card p-12 text-center">
          <Wallet className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">Nenhuma conta cadastrada ainda</p>
          <Button className="mt-4" onClick={() => setOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Adicionar conta
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {accounts.map((acc) => {
            const cfg = ACCOUNT_TYPE_CONFIG[acc.type]
            const Icon = cfg.icon
            return (
              <div
                key={acc.id}
                className="ft-card p-5 group hover:shadow-md transition-all duration-200"
                style={{ borderLeft: `4px solid ${acc.color}` }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center"
                      style={{ background: acc.color + '22' }}
                    >
                      <Icon className="h-5 w-5" style={{ color: acc.color }} />
                    </div>
                    <div>
                      <p className="font-semibold text-sm">{acc.name}</p>
                      <p className="text-xs text-muted-foreground">{cfg.label}</p>
                    </div>
                  </div>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 text-xs px-2"
                      onClick={() => { setEditAccount(acc); setOpen(true) }}
                    >
                      Editar
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 text-xs px-2 text-destructive"
                      onClick={() => handleDelete(acc)}
                    >
                      Excluir
                    </Button>
                  </div>
                </div>
                {acc.bank_name && (
                  <p className="text-xs text-muted-foreground mb-2">{acc.bank_name}</p>
                )}
                <p className={cn(
                  'text-2xl font-bold number-display',
                  acc.balance < 0 ? 'text-red-600' : 'text-foreground'
                )}>
                  {formatCurrency(acc.balance)}
                </p>
              </div>
            )
          })}
        </div>
      )}

      <AccountDialog
        open={open}
        onClose={() => { setOpen(false); setEditAccount(null) }}
        onSave={handleSave}
        account={editAccount}
      />
    </div>
  )
}
