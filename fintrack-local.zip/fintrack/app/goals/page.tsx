'use client'

import { useState } from 'react'
import { Plus, Target, CheckCircle2 } from 'lucide-react'
import { useGoals } from '@/hooks'
import { useAuthStore, useGoalStore } from '@/store'
import { createGoal, updateGoal, deleteGoal } from '@/services/goals'
import { formatCurrency, calculatePercentage, estimateGoalMonths } from '@/utils'
import { cn } from '@/utils'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/components/ui/use-toast'
import { GoalDialog } from '@/components/goals/GoalDialog'
import { GoalContributeDialog } from '@/components/goals/GoalContributeDialog'
import type { Goal, GoalFormData } from '@/types'

const STATUS_CONFIG: Record<string, { label: string; class: string }> = {
  active: { label: 'Ativa', class: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400' },
  completed: { label: 'Concluída', class: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400' },
  paused: { label: 'Pausada', class: 'bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400' },
  cancelled: { label: 'Cancelada', class: 'bg-muted text-muted-foreground' },
}

export default function GoalsPage() {
  const { user } = useAuthStore()
  const { goals, isLoading, refetch } = useGoals()
  const { addGoal, updateGoal: updateStore, removeGoal } = useGoalStore()
  const { toast } = useToast()
  const [open, setOpen] = useState(false)
  const [editGoal, setEditGoal] = useState<Goal | null>(null)
  const [contributeGoal, setContributeGoal] = useState<Goal | null>(null)

  const activeGoals = goals.filter((g) => g.status === 'active')
  const completedGoals = goals.filter((g) => g.status === 'completed')

  const handleSave = async (data: GoalFormData) => {
    if (!user) return
    try {
      if (editGoal) {
        const updated = await updateGoal(editGoal.id, user.user_id, data)
        updateStore(editGoal.id, updated)
        toast({ title: 'Meta atualizada' })
      } else {
        const created = await createGoal(user.user_id, data)
        addGoal(created)
        toast({ title: 'Meta criada!' })
      }
      setOpen(false)
      setEditGoal(null)
    } catch (e: any) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' })
    }
  }

  const handleDelete = async (goal: Goal) => {
    if (!user) return
    try {
      await deleteGoal(goal.id, user.user_id)
      removeGoal(goal.id)
      toast({ title: 'Meta removida' })
    } catch (e: any) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' })
    }
  }

  const handleContribute = async (amount: number) => {
    if (!user || !contributeGoal) return
    try {
      const newAmount = Math.min(contributeGoal.current_amount + amount, contributeGoal.target_amount)
      const updated = await updateGoal(contributeGoal.id, user.user_id, {
        ...contributeGoal,
        current_amount: newAmount,
      })
      updateStore(contributeGoal.id, updated)
      toast({ title: 'Contribuição registrada!', description: `${formatCurrency(amount)} adicionado à meta.` })
      setContributeGoal(null)
    } catch (e: any) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' })
    }
  }

  function GoalCard({ goal }: { goal: Goal }) {
    const pct = calculatePercentage(goal.current_amount, goal.target_amount)
    const monthsLeft =
      goal.monthly_contribution && goal.monthly_contribution > 0
        ? estimateGoalMonths(goal.target_amount, goal.current_amount, goal.monthly_contribution)
        : null

    return (
      <div className="ft-card p-6 group hover:shadow-md transition-all duration-200">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div
              className="w-11 h-11 rounded-xl flex items-center justify-center text-xl"
              style={{ background: goal.color + '22', border: `2px solid ${goal.color}44` }}
            >
              {goal.icon}
            </div>
            <div>
              <p className="font-semibold">{goal.name}</p>
              {goal.description && (
                <p className="text-xs text-muted-foreground mt-0.5">{goal.description}</p>
              )}
            </div>
          </div>
          <Badge className={cn('text-[10px]', STATUS_CONFIG[goal.status]?.class)}>
            {STATUS_CONFIG[goal.status]?.label}
          </Badge>
        </div>

        <div className="space-y-2 mb-4">
          <div className="flex justify-between text-sm">
            <span className="font-medium number-display">{formatCurrency(goal.current_amount)}</span>
            <span className="text-muted-foreground">de {formatCurrency(goal.target_amount)}</span>
          </div>
          <div className="progress-bar">
            <div
              className="progress-fill"
              style={{ width: `${Math.min(pct, 100)}%`, background: goal.color }}
            />
          </div>
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>{pct.toFixed(1)}% concluído</span>
            {monthsLeft !== null && isFinite(monthsLeft) && (
              <span>~{monthsLeft} meses restantes</span>
            )}
          </div>
        </div>

        {goal.status === 'completed' && (
          <div className="flex items-center gap-2 text-emerald-600 text-sm font-medium mb-4">
            <CheckCircle2 className="h-4 w-4" />
            Meta alcançada!
          </div>
        )}

        <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
          {goal.status === 'active' && (
            <Button size="sm" className="flex-1 h-8 text-xs" onClick={() => setContributeGoal(goal)}>
              Contribuir
            </Button>
          )}
          <Button
            variant="outline" size="sm" className="h-8 text-xs"
            onClick={() => { setEditGoal(goal); setOpen(true) }}
          >
            Editar
          </Button>
          <Button
            variant="outline" size="sm"
            className="h-8 text-xs text-destructive hover:text-destructive"
            onClick={() => handleDelete(goal)}
          >
            Excluir
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold">Metas Financeiras</h1>
          <p className="text-muted-foreground text-sm mt-1">
            {activeGoals.length} ativa{activeGoals.length !== 1 ? 's' : ''}
            {completedGoals.length > 0 && ` · ${completedGoals.length} concluída${completedGoals.length !== 1 ? 's' : ''}`}
          </p>
        </div>
        <Button onClick={() => { setEditGoal(null); setOpen(true) }} className="gap-2">
          <Plus className="h-4 w-4" />
          Nova meta
        </Button>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="ft-card h-48 animate-pulse bg-muted" />
          ))}
        </div>
      ) : goals.length === 0 ? (
        <div className="ft-card p-12 text-center">
          <Target className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground mb-1">Nenhuma meta cadastrada</p>
          <p className="text-xs text-muted-foreground">Defina objetivos para organizar suas economias</p>
          <Button className="mt-4" onClick={() => setOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Criar primeira meta
          </Button>
        </div>
      ) : (
        <>
          {activeGoals.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {activeGoals.map((g) => <GoalCard key={g.id} goal={g} />)}
            </div>
          )}
          {completedGoals.length > 0 && (
            <>
              <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider pt-2">
                Concluídas
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {completedGoals.map((g) => <GoalCard key={g.id} goal={g} />)}
              </div>
            </>
          )}
        </>
      )}

      <GoalDialog
        open={open}
        onClose={() => { setOpen(false); setEditGoal(null) }}
        onSave={handleSave}
        goal={editGoal}
      />

      {contributeGoal && (
        <GoalContributeDialog
          open={!!contributeGoal}
          goal={contributeGoal}
          onClose={() => setContributeGoal(null)}
          onConfirm={handleContribute}
        />
      )}
    </div>
  )
}
