'use client'

import { useState } from 'react'
import { Plus, TrendingUp, TrendingDown } from 'lucide-react'
import { useInvestments } from '@/hooks'
import { useAuthStore } from '@/store'
import { createInvestment, updateInvestment, deleteInvestment, getInvestmentSummary } from '@/services/investments'
import { formatCurrency, formatPercent, CHART_COLORS } from '@/utils'
import { cn } from '@/utils'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/components/ui/use-toast'
import { InvestmentDialog } from '@/components/investments/InvestmentDialog'
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts'
import type { Investment } from '@/types'

const TYPE_LABELS: Record<string, string> = {
  stocks: 'Ações',
  fii: 'FIIs',
  treasury: 'Tesouro Direto',
  cdb: 'CDB',
  crypto: 'Cripto',
  other: 'Outros',
}

export default function InvestmentsPage() {
  const { user } = useAuthStore()
  const { investments, isLoading, refetch } = useInvestments()
  const { toast } = useToast()
  const [open, setOpen] = useState(false)
  const [editInv, setEditInv] = useState<Investment | null>(null)

  const summary = getInvestmentSummary(investments)
  const pieData = Object.entries(summary.byType).map(([type, value]) => ({
    name: TYPE_LABELS[type] || type,
    value,
  }))

  const handleSave = async (data: Omit<Investment, 'id' | 'user_id' | 'created_at' | 'updated_at'>) => {
    if (!user) return
    try {
      if (editInv) {
        await updateInvestment(editInv.id, user.user_id, data)
        toast({ title: 'Investimento atualizado' })
      } else {
        await createInvestment(user.user_id, data)
        toast({ title: 'Investimento cadastrado' })
      }
      setOpen(false)
      setEditInv(null)
      refetch()
    } catch (e: any) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' })
    }
  }

  const handleDelete = async (inv: Investment) => {
    if (!user) return
    try {
      await deleteInvestment(inv.id, user.user_id)
      refetch()
      toast({ title: 'Investimento removido' })
    } catch (e: any) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' })
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold">Investimentos</h1>
          <p className="text-muted-foreground text-sm mt-1">
            {investments.length} ativo{investments.length !== 1 ? 's' : ''} cadastrado{investments.length !== 1 ? 's' : ''}
          </p>
        </div>
        <Button onClick={() => { setEditInv(null); setOpen(true) }} className="gap-2">
          <Plus className="h-4 w-4" />
          Novo investimento
        </Button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Valor atual', value: formatCurrency(summary.total), color: '' },
          { label: 'Total investido', value: formatCurrency(summary.invested), color: '' },
          {
            label: 'Rentabilidade',
            value: formatPercent(summary.profitability),
            color: summary.profitability >= 0 ? 'text-emerald-600' : 'text-red-600',
          },
          {
            label: 'Lucro / Prejuízo',
            value: formatCurrency(summary.profit),
            color: summary.profit >= 0 ? 'text-emerald-600' : 'text-red-600',
          },
        ].map((item) => (
          <div key={item.label} className="ft-card p-5">
            <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">{item.label}</p>
            <p className={cn('text-xl font-bold number-display', item.color)}>{item.value}</p>
          </div>
        ))}
      </div>

      {investments.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Diversification pie */}
          <div className="ft-card p-6">
            <h3 className="text-base font-semibold mb-4">Diversificação</h3>
            {pieData.length > 0 ? (
              <>
                <ResponsiveContainer width="100%" height={180}>
                  <PieChart>
                    <Pie
                      data={pieData}
                      dataKey="value"
                      cx="50%"
                      cy="50%"
                      outerRadius={70}
                      innerRadius={35}
                    >
                      {pieData.map((_, i) => (
                        <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(v: any) => formatCurrency(v)} />
                  </PieChart>
                </ResponsiveContainer>
                <div className="mt-3 space-y-1.5">
                  {pieData.map((item, i) => (
                    <div key={item.name} className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span
                          className="w-2 h-2 rounded-full"
                          style={{ background: CHART_COLORS[i % CHART_COLORS.length] }}
                        />
                        <span className="text-muted-foreground">{item.name}</span>
                      </div>
                      <span className="font-medium number-display">{formatCurrency(item.value)}</span>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-8">Sem dados</p>
            )}
          </div>

          {/* Portfolio table */}
          <div className="lg:col-span-2 ft-card overflow-hidden">
            <div className="p-6 border-b border-border">
              <h3 className="text-base font-semibold">Portfólio</h3>
            </div>
            <div className="divide-y divide-border">
              {investments.map((inv) => {
                const profit = inv.current_value - inv.invested_amount
                const isPositive = profit >= 0

                return (
                  <div
                    key={inv.id}
                    className="flex items-center gap-4 px-6 py-4 hover:bg-accent/30 transition-colors group"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-semibold text-sm">{inv.name}</p>
                        {inv.ticker && (
                          <Badge variant="secondary" className="text-[10px]">{inv.ticker}</Badge>
                        )}
                        <Badge variant="outline" className="text-[10px]">
                          {TYPE_LABELS[inv.type] ?? inv.type}
                        </Badge>
                      </div>
                      {inv.broker && (
                        <p className="text-xs text-muted-foreground mt-0.5">{inv.broker}</p>
                      )}
                    </div>

                    <div className="text-right shrink-0">
                      <p className="text-sm font-bold number-display">{formatCurrency(inv.current_value)}</p>
                      <div className={cn(
                        'flex items-center gap-1 justify-end text-xs font-medium',
                        isPositive ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'
                      )}>
                        {isPositive
                          ? <TrendingUp className="h-3 w-3" />
                          : <TrendingDown className="h-3 w-3" />
                        }
                        {formatPercent(inv.profitability)}
                      </div>
                    </div>

                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                      <Button
                        variant="ghost" size="sm" className="h-7 text-xs"
                        onClick={() => { setEditInv(inv); setOpen(true) }}
                      >
                        Editar
                      </Button>
                      <Button
                        variant="ghost" size="sm" className="h-7 text-xs text-destructive"
                        onClick={() => handleDelete(inv)}
                      >
                        Excluir
                      </Button>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      )}

      {investments.length === 0 && !isLoading && (
        <div className="ft-card p-12 text-center">
          <TrendingUp className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">Nenhum investimento cadastrado</p>
          <Button className="mt-4" onClick={() => setOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Cadastrar investimento
          </Button>
        </div>
      )}

      <InvestmentDialog
        open={open}
        onClose={() => { setOpen(false); setEditInv(null) }}
        onSave={handleSave}
        investment={editInv}
      />
    </div>
  )
}
