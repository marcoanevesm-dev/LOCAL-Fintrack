'use client'

import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useState } from 'react'
import { Moon, Sun, Monitor, User, Shield, Palette } from 'lucide-react'
import { useTheme } from 'next-themes'
import { createClient } from '@/lib/supabase'
import { useAuthStore } from '@/store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { useToast } from '@/components/ui/use-toast'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { getInitials } from '@/utils'
import { cn } from '@/utils'

const profileSchema = z.object({
  name: z.string().min(2, 'Nome deve ter no mínimo 2 caracteres'),
  monthly_income: z.number({ coerce: true }).min(0).optional(),
})

type ProfileForm = z.infer<typeof profileSchema>

export default function SettingsPage() {
  const { user, setUser } = useAuthStore()
  const { theme, setTheme } = useTheme()
  const { toast } = useToast()
  const supabase = createClient()
  const [saving, setSaving] = useState(false)

  const { register, handleSubmit, formState: { errors } } = useForm<ProfileForm>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: user?.name ?? '',
      monthly_income: user?.monthly_income ?? undefined,
    },
  })

  const saveProfile = async (data: ProfileForm) => {
    if (!user) return
    setSaving(true)
    try {
      const { data: updated, error } = await supabase
        .from('profiles')
        .update({
          name: data.name,
          monthly_income: data.monthly_income ?? null,
          updated_at: new Date().toISOString(),
        })
        .eq('user_id', user.user_id)
        .select()
        .single()

      if (error) throw error
      setUser({ ...user, ...updated })
      toast({ title: 'Perfil atualizado' })
    } catch (e: any) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  const THEME_OPTIONS = [
    { value: 'light', label: 'Claro', icon: Sun },
    { value: 'dark', label: 'Escuro', icon: Moon },
    { value: 'system', label: 'Sistema', icon: Monitor },
  ]

  return (
    <div className="max-w-2xl space-y-8">
      <div>
        <h1 className="text-2xl font-bold">Configurações</h1>
        <p className="text-muted-foreground text-sm mt-1">Gerencie sua conta e preferências</p>
      </div>

      {/* Profile */}
      <div className="ft-card p-6 space-y-6">
        <div className="flex items-center gap-2">
          <User className="h-4 w-4 text-muted-foreground" />
          <h2 className="font-semibold">Perfil</h2>
        </div>
        <Separator />

        <div className="flex items-center gap-4">
          <Avatar className="h-16 w-16">
            <AvatarFallback className="bg-primary text-primary-foreground text-xl">
              {getInitials(user?.name ?? 'U')}
            </AvatarFallback>
          </Avatar>
          <div>
            <p className="font-medium">{user?.name}</p>
            <p className="text-sm text-muted-foreground">{user?.email}</p>
          </div>
        </div>

        <form onSubmit={handleSubmit(saveProfile)} className="space-y-4">
          <div className="space-y-1.5">
            <Label>Nome</Label>
            <Input {...register('name')} />
            {errors.name && (
              <p className="text-xs text-destructive">{errors.name.message}</p>
            )}
          </div>
          <div className="space-y-1.5">
            <Label>Renda mensal (R$) — usada para análises e insights</Label>
            <Input
              type="number"
              step="0.01"
              placeholder="0,00"
              {...register('monthly_income')}
            />
          </div>
          <Button type="submit" disabled={saving}>
            {saving ? 'Salvando...' : 'Salvar perfil'}
          </Button>
        </form>
      </div>

      {/* Appearance */}
      <div className="ft-card p-6 space-y-6">
        <div className="flex items-center gap-2">
          <Palette className="h-4 w-4 text-muted-foreground" />
          <h2 className="font-semibold">Aparência</h2>
        </div>
        <Separator />
        <div>
          <p className="text-sm font-medium mb-3">Tema</p>
          <div className="flex gap-3">
            {THEME_OPTIONS.map((opt) => {
              const Icon = opt.icon
              return (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => setTheme(opt.value)}
                  className={cn(
                    'flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-all text-sm font-medium flex-1',
                    theme === opt.value
                      ? 'border-primary bg-accent text-foreground'
                      : 'border-border hover:border-primary/50 text-muted-foreground'
                  )}
                >
                  <Icon className="h-5 w-5" />
                  {opt.label}
                </button>
              )
            })}
          </div>
        </div>
      </div>

      {/* Security */}
      <div className="ft-card p-6 space-y-6">
        <div className="flex items-center gap-2">
          <Shield className="h-4 w-4 text-muted-foreground" />
          <h2 className="font-semibold">Segurança</h2>
        </div>
        <Separator />
        <div className="space-y-4 text-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">E-mail verificado</p>
              <p className="text-xs text-muted-foreground">{user?.email}</p>
            </div>
            <span className="text-xs bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 px-2 py-1 rounded-full font-medium">
              Verificado
            </span>
          </div>
          <Separator />
          <div>
            <p className="font-medium mb-1">Proteção dos dados</p>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Seus dados são armazenados com segurança no Supabase. Row Level Security
              garante que apenas você acessa suas informações. Senhas são gerenciadas
              pelo Supabase Auth e nunca ficam expostas no código.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
