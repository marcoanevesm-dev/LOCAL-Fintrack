'use client'

import { useState, useEffect } from 'react'
import { Plus, CreditCard as CreditCardIcon, AlertCircle } from 'lucide-react'
import {
  getCreditCards,
  createCreditCard,
  updateCreditCard,
  deleteCreditCard,
  getCardBillAmount,
} from '@/services/credit-cards'
import { useAuthStore } from '@/store'
import { formatCurrency, calculatePercentage } from '@/utils'
import { cn } from '@/utils'
import { Button } from '@/components/ui/button'
import { useToast } from '@/components/ui/use-toast'
import { CreditCardDialog } from '@/components/credit-cards/CreditCardDialog'
import type { CreditCard, CreditCardFormData } from '@/types'

type CardWithBill = CreditCard & { bill: number }

export default function CreditCardsPage() {
  const { user } = useAuthStore()
  const { toast } = useToast()
  const [cards, setCards] = useState<CardWithBill[]>([])
  const [loading, setLoading] = useState(false)
  const [open, setOpen] = useState(false)
  const [editCard, setEditCard] = useState<CreditCard | null>(null)

  const fetchCards = async () => {
    if (!user) return
    setLoading(true)
    try {
      const raw = await getCreditCards(user.user_id)
      const withBills = await Promise.all(
        raw.map(async (c) => ({
          ...c,
          bill: await getCardBillAmount(user.user_id, c.closing_day),
        }))
      )
      setCards(withBills)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchCards() }, [user])

  const handleSave = async (data: CreditCardFormData) => {
    if (!user) return
    try {
      if (editCard) {
        await updateCreditCard(editCard.id, user.user_id, data)
        toast({ title: 'Cartão atualizado' })
      } else {
        await createCreditCard(user.user_id, data)
        toast({ title: 'Cartão cadastrado' })
      }
      setOpen(false)
      setEditCard(null)
      fetchCards()
    } catch (e: any) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' })
    }
  }

  const handleDelete = async (card: CreditCard) => {
    if (!user) return
    try {
      await deleteCreditCard(card.id, user.user_id)
      setCards((prev) => prev.filter((c) => c.id !== card.id))
      toast({ title: 'Cartão removido' })
    } catch (e: any) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' })
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold">Cartões de Crédito</h1>
          <p className="text-muted-foreground text-sm mt-1">
            {cards.length} cartão{cards.length !== 1 ? 'ões' : ''} cadastrado{cards.length !== 1 ? 's' : ''}
          </p>
        </div>
        <Button onClick={() => { setEditCard(null); setOpen(true) }} className="gap-2">
          <Plus className="h-4 w-4" />
          Novo cartão
        </Button>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(2)].map((_, i) => (
            <div key={i} className="h-52 rounded-2xl animate-pulse bg-muted" />
          ))}
        </div>
      ) : cards.length === 0 ? (
        <div className="ft-card p-12 text-center">
          <CreditCardIcon className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">Nenhum cartão cadastrado</p>
          <Button className="mt-4" onClick={() => setOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Cadastrar cartão
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {cards.map((card) => {
            const limitUsedPct = calculatePercentage(card.bill, card.limit_amount)
            const available = card.limit_amount - card.bill
            const isNearLimit = limitUsedPct >= 80

            return (
              <div key={card.id} className="group">
                {/* Card visual */}
                <div
                  className="relative h-44 rounded-2xl p-6 text-white flex flex-col justify-between overflow-hidden shadow-lg"
                  style={{ background: `linear-gradient(135deg, ${card.color}, ${card.color}99)` }}
                >
                  <div className="absolute -right-8 -top-8 w-32 h-32 rounded-full bg-white/10" />
                  <div className="absolute -right-4 top-10 w-20 h-20 rounded-full bg-white/10" />

                  <div className="relative flex items-start justify-between">
                    <div>
                      <p className="text-white/70 text-xs font-medium">{card.bank_name}</p>
                      <p className="text-white font-bold text-lg mt-0.5">{card.name}</p>
                    </div>
                    <CreditCardIcon className="h-8 w-8 text-white/60" />
                  </div>

                  <div className="relative">
                    {card.last_four_digits && (
                      <p className="text-white/60 text-sm font-mono tracking-widest mb-2">
                        •••• •••• •••• {card.last_four_digits}
                      </p>
                    )}
                    <div className="flex justify-between items-end">
                      <div>
                        <p className="text-white/60 text-[10px] uppercase tracking-wider">Fatura atual</p>
                        <p className="text-white font-bold text-xl number-display">
                          {formatCurrency(card.bill)}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-white/60 text-[10px] uppercase tracking-wider">Limite</p>
                        <p className="text-white font-semibold text-sm number-display">
                          {formatCurrency(card.limit_amount)}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Info panel */}
                <div className="ft-card mt-3 p-4 space-y-3">
                  <div>
                    <div className="flex justify-between text-xs text-muted-foreground mb-1.5">
                      <span>Utilizado: {limitUsedPct.toFixed(0)}%</span>
                      <span>Disponível: {formatCurrency(available)}</span>
                    </div>
                    <div className="progress-bar">
                      <div
                        className={cn('progress-fill', isNearLimit ? 'bg-red-500' : 'bg-emerald-500')}
                        style={{ width: `${Math.min(limitUsedPct, 100)}%` }}
                      />
                    </div>
                  </div>

                  {isNearLimit && (
                    <div className="flex items-center gap-2 text-xs text-amber-600 dark:text-amber-400">
                      <AlertCircle className="h-3.5 w-3.5" />
                      Limite quase atingido
                    </div>
                  )}

                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Fecha dia <strong className="text-foreground">{card.closing_day}</strong></span>
                    <span>Vence dia <strong className="text-foreground">{card.due_day}</strong></span>
                  </div>

                  <div className="flex gap-2 pt-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button
                      variant="outline" size="sm" className="flex-1 h-8 text-xs"
                      onClick={() => { setEditCard(card); setOpen(true) }}
                    >
                      Editar
                    </Button>
                    <Button
                      variant="outline" size="sm"
                      className="flex-1 h-8 text-xs text-destructive hover:text-destructive"
                      onClick={() => handleDelete(card)}
                    >
                      Excluir
                    </Button>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      )}

      <CreditCardDialog
        open={open}
        onClose={() => { setOpen(false); setEditCard(null) }}
        onSave={handleSave}
        card={editCard}
      />
    </div>
  )
}
