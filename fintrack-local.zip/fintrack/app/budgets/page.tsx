'use client'

import { useState, useEffect } from 'react'
import { Plus, PieChart } from 'lucide-react'
import { getBudgets, createBudget, updateBudget, deleteBudget } from '@/services/budgets'
import { useAuthStore } from '@/store'
import { useCategories } from '@/hooks'
import { formatCurrency, calculatePercentage, getMonthName } from '@/utils'
import { cn } from '@/utils'
import { Button } from '@/components/ui/button'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { useToast } from '@/components/ui/use-toast'
import { BudgetDialog } from '@/components/budgets/BudgetDialog'
import type { Budget, BudgetFormData } from '@/types'

const MONTHS = Array.from({ length: 12 }, (_, i) => ({
  value: i + 1,
  label: getMonthName(i + 1),
}))

export default function BudgetsPage() {
  const { user } = useAuthStore()
  const { expenseCategories } = useCategories()
  const { toast } = useToast()
  const now = new Date()
  const [month, setMonth] = useState(now.getMonth() + 1)
  const [year, setYear] = useState(now.getFullYear())
  const [budgets, setBudgets] = useState<Budget[]>([])
  const [loading, setLoading] = useState(false)
  const [open, setOpen] = useState(false)
  const [editBudget, setEditBudget] = useState<Budget | null>(null)

  const fetchBudgets = async () => {
    if (!user) return
    setLoading(true)
    try {
      const data = await getBudgets(user.user_id, month, year)
      setBudgets(data)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { fetchBudgets() }, [user, month, year])

  const handleSave = async (data: BudgetFormData) => {
    if (!user) return
    try {
      if (editBudget) {
        const updated = await updateBudget(editBudget.id, user.user_id, data)
        setBudgets((prev) => prev.map((b) => (b.id === editBudget.id ? updated : b)))
        toast({ title: 'Orçamento atualizado' })
      } else {
        const created = await createBudget(user.user_id, { ...data, month, year })
        setBudgets((prev) => [...prev, created])
        toast({ title: 'Orçamento criado' })
      }
      setOpen(false)
      setEditBudget(null)
    } catch (e: any) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' })
    }
  }

  const handleDelete = async (budget: Budget) => {
    if (!user) return
    try {
      await deleteBudget(budget.id, user.user_id)
      setBudgets((prev) => prev.filter((b) => b.id !== budget.id))
      toast({ title: 'Orçamento removido' })
    } catch (e: any) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' })
    }
  }

  const totalBudget = budgets.reduce((s, b) => s + b.amount, 0)
  const totalSpent = budgets.reduce((s, b) => s + (b.spent ?? 0), 0)

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold">Orçamentos</h1>
          <p className="text-muted-foreground text-sm mt-1">
            {getMonthName(month)} {year}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={String(month)} onValueChange={(v) => setMonth(Number(v))}>
            <SelectTrigger className="w-36">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {MONTHS.map((m) => (
                <SelectItem key={m.value} value={String(m.value)}>{m.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button onClick={() => { setEditBudget(null); setOpen(true) }} className="gap-2">
            <Plus className="h-4 w-4" />
            Novo orçamento
          </Button>
        </div>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 gap-4">
        <div className="ft-card p-5">
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Total orçado</p>
          <p className="text-2xl font-bold number-display">{formatCurrency(totalBudget)}</p>
        </div>
        <div className="ft-card p-5">
          <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Total gasto</p>
          <p className={cn(
            'text-2xl font-bold number-display',
            totalSpent > totalBudget ? 'text-red-600' : 'text-foreground'
          )}>
            {formatCurrency(totalSpent)}
          </p>
        </div>
      </div>

      {loading ? (
        <div className="space-y-3">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="ft-card h-24 animate-pulse bg-muted" />
          ))}
        </div>
      ) : budgets.length === 0 ? (
        <div className="ft-card p-12 text-center">
          <PieChart className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">Nenhum orçamento para {getMonthName(month)}</p>
          <Button className="mt-4" onClick={() => setOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Criar orçamento
          </Button>
        </div>
      ) : (
        <div className="space-y-3">
          {budgets.map((budget) => {
            const pct = calculatePercentage(budget.spent ?? 0, budget.amount)
            const isAlert = pct >= budget.alert_threshold && pct < 100
            const isOver = pct >= 100

            return (
              <div key={budget.id} className="ft-card p-5 group hover:shadow-sm transition-all">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <span
                      className="w-3 h-3 rounded-full shrink-0"
                      style={{ background: budget.category?.color }}
                    />
                    <span className="font-medium">{budget.category?.name}</span>
                    {isAlert && !isOver && (
                      <span className="text-[10px] bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 px-2 py-0.5 rounded-full font-medium">
                        {pct.toFixed(0)}% usado
                      </span>
                    )}
                    {isOver && (
                      <span className="text-[10px] bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400 px-2 py-0.5 rounded-full font-medium">
                        Excedido
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-muted-foreground number-display">
                      {formatCurrency(budget.spent ?? 0)} / {formatCurrency(budget.amount)}
                    </span>
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button
                        variant="ghost" size="sm" className="h-7 text-xs"
                        onClick={() => { setEditBudget(budget); setOpen(true) }}
                      >
                        Editar
                      </Button>
                      <Button
                        variant="ghost" size="sm" className="h-7 text-xs text-destructive"
                        onClick={() => handleDelete(budget)}
                      >
                        Excluir
                      </Button>
                    </div>
                  </div>
                </div>
                <div className="progress-bar">
                  <div
                    className="progress-fill"
                    style={{
                      width: `${Math.min(pct, 100)}%`,
                      background: isOver ? '#ef4444' : isAlert ? '#f59e0b' : (budget.category?.color ?? '#6366f1'),
                    }}
                  />
                </div>
                {isAlert && !isOver && (
                  <p className="text-xs text-amber-600 dark:text-amber-400 mt-2">
                    Atenção: {pct.toFixed(0)}% do limite de {budget.alert_threshold}% atingido
                  </p>
                )}
              </div>
            )
          })}
        </div>
      )}

      <BudgetDialog
        open={open}
        onClose={() => { setOpen(false); setEditBudget(null) }}
        onSave={handleSave}
        budget={editBudget}
        categories={expenseCategories}
        month={month}
        year={year}
      />
    </div>
  )
}
