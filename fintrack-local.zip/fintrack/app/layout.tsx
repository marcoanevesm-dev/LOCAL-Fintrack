import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import { ThemeProvider } from '@/components/layout/ThemeProvider'
import { Toaster } from '@/components/ui/toaster'
import './globals.css'

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' })

export const metadata: Metadata = {
  title: 'FinTrack — Controle Financeiro Inteligente',
  description: 'Gerencie sua vida financeira com clareza. Transações, metas, orçamentos e investimentos em um só lugar.',
  keywords: 'finanças pessoais, controle financeiro, orçamento, investimentos, metas financeiras',
  authors: [{ name: 'FinTrack' }],
  openGraph: {
    title: 'FinTrack — Controle Financeiro Inteligente',
    description: 'Gerencie sua vida financeira com clareza.',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <body className={`${inter.variable} font-sans antialiased`}>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  )
}
