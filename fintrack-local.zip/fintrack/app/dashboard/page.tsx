'use client'

import { useDashboard } from '@/hooks'
import { useUIStore } from '@/store'
import { formatCurrency, formatPercent } from '@/utils'
import { StatCard } from '@/components/dashboard/StatCard'
import { EvolutionChart } from '@/components/dashboard/EvolutionChart'
import { CategoryPieChart } from '@/components/dashboard/CategoryPieChart'
import { InsightsPanel } from '@/components/dashboard/InsightsPanel'
import { RecentTransactions } from '@/components/dashboard/RecentTransactions'
import { GoalsSummary } from '@/components/dashboard/GoalsSummary'
import { BudgetOverview } from '@/components/dashboard/BudgetOverview'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Wallet, TrendingUp, TrendingDown, PiggyBank,
} from 'lucide-react'

export default function DashboardPage() {
  const { summary, evolution, categorySpending, insights, isLoading } = useDashboard()
  const { showBalances } = useUIStore()

  const mask = (val: number) => showBalances ? formatCurrency(val) : '••••••'

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-64" />
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-32" />)}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Skeleton className="h-80 lg:col-span-2" />
          <Skeleton className="h-80" />
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="animate-fade-up">
        <h1 className="text-2xl font-bold">Visão Geral</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Acompanhe sua saúde financeira em tempo real
        </p>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          className="stat-card-balance animate-fade-up animate-fade-up-1"
          title="Saldo Total"
          value={mask(summary?.total_balance || 0)}
          icon={<Wallet className="h-5 w-5 text-indigo-600" />}
          subtitle="Todas as contas"
        />
        <StatCard
          className="stat-card-income animate-fade-up animate-fade-up-2"
          title="Receitas"
          value={mask(summary?.monthly_income || 0)}
          icon={<TrendingUp className="h-5 w-5 text-emerald-600" />}
          subtitle="Este mês"
        />
        <StatCard
          className="stat-card-expense animate-fade-up animate-fade-up-3"
          title="Despesas"
          value={mask(summary?.monthly_expenses || 0)}
          icon={<TrendingDown className="h-5 w-5 text-red-600" />}
          subtitle="Este mês"
        />
        <StatCard
          className="stat-card-savings animate-fade-up animate-fade-up-4"
          title="Economias"
          value={mask(summary?.monthly_savings || 0)}
          icon={<PiggyBank className="h-5 w-5 text-amber-600" />}
          subtitle={`Taxa: ${formatPercent(summary?.savings_rate || 0)}`}
          highlight={summary?.monthly_savings !== undefined && summary.monthly_savings > 0}
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <EvolutionChart data={evolution} />
        </div>
        <div>
          <CategoryPieChart data={categorySpending} />
        </div>
      </div>

      {/* Middle Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <RecentTransactions />
        </div>
        <div>
          <InsightsPanel insights={insights} />
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <GoalsSummary />
        <BudgetOverview />
      </div>
    </div>
  )
}
