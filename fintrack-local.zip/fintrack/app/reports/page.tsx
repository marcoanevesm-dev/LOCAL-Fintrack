'use client'

import { useState } from 'react'
import { Download, FileText, BarChart3 } from 'lucide-react'
import { useAuthStore } from '@/store'
import { getTransactions, getCategorySpending } from '@/services/transactions'
import { formatCurrency, formatDate } from '@/utils'
import { cn } from '@/utils'
import { Button } from '@/components/ui/button'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { useToast } from '@/components/ui/use-toast'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer,
} from 'recharts'
import type { Transaction } from '@/types'

type Period = 'month' | 'quarter' | 'year'

function getPeriodRange(period: Period) {
  const now = new Date()
  const end = now.toISOString().split('T')[0]
  let start: string
  if (period === 'month') {
    start = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-01`
  } else if (period === 'quarter') {
    const q = new Date(now)
    q.setMonth(q.getMonth() - 2)
    start = `${q.getFullYear()}-${String(q.getMonth() + 1).padStart(2, '0')}-01`
  } else {
    start = `${now.getFullYear()}-01-01`
  }
  return { start, end }
}

interface ReportData {
  transactions: Transaction[]
  categorySpending: Array<{ category_id: string; category_name: string; color: string; amount: number }>
  income: number
  expenses: number
  start: string
  end: string
}

export default function ReportsPage() {
  const { user } = useAuthStore()
  const { toast } = useToast()
  const [period, setPeriod] = useState<Period>('month')
  const [loading, setLoading] = useState(false)
  const [reportData, setReportData] = useState<ReportData | null>(null)

  const generateReport = async () => {
    if (!user) return
    setLoading(true)
    try {
      const { start, end } = getPeriodRange(period)
      const [transactions, categorySpending] = await Promise.all([
        getTransactions(user.user_id, { start_date: start, end_date: end }),
        getCategorySpending(user.user_id, start, end),
      ])

      const income = transactions
        .filter((t) => t.type === 'income')
        .reduce((s, t) => s + t.amount, 0)
      const expenses = transactions
        .filter((t) => t.type === 'expense')
        .reduce((s, t) => s + t.amount, 0)

      setReportData({ transactions, categorySpending, income, expenses, start, end })
    } catch (e: any) {
      toast({ title: 'Erro ao gerar relatório', description: e.message, variant: 'destructive' })
    } finally {
      setLoading(false)
    }
  }

  const exportCSV = () => {
    if (!reportData) return
    const rows = [
      ['Data', 'Descrição', 'Categoria', 'Conta', 'Tipo', 'Valor'],
      ...reportData.transactions.map((t) => [
        formatDate(t.date),
        t.description,
        t.category?.name ?? '',
        t.account?.name ?? '',
        t.type === 'income' ? 'Receita' : 'Despesa',
        t.amount.toFixed(2),
      ]),
    ]
    const csv = rows.map((r) => r.join(';')).join('\n')
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `fintrack-relatorio-${period}.csv`
    a.click()
    URL.revokeObjectURL(url)
    toast({ title: 'CSV exportado com sucesso' })
  }

  const exportJSON = () => {
    if (!reportData) return
    const blob = new Blob(
      [JSON.stringify(reportData.transactions, null, 2)],
      { type: 'application/json' }
    )
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `fintrack-relatorio-${period}.json`
    a.click()
    URL.revokeObjectURL(url)
    toast({ title: 'JSON exportado com sucesso' })
  }

  const balance = reportData ? reportData.income - reportData.expenses : 0

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold">Relatórios</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Gere e exporte análises das suas finanças
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={period} onValueChange={(v) => setPeriod(v as Period)}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="month">Mensal</SelectItem>
              <SelectItem value="quarter">Trimestral</SelectItem>
              <SelectItem value="year">Anual</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={generateReport} disabled={loading}>
            {loading ? 'Gerando...' : 'Gerar relatório'}
          </Button>
        </div>
      </div>

      {!reportData ? (
        <div className="ft-card p-16 text-center">
          <BarChart3 className="h-14 w-14 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground text-base font-medium">
            Selecione um período e gere o relatório
          </p>
          <p className="text-muted-foreground text-sm mt-1">
            Você poderá exportar em CSV ou JSON após gerar
          </p>
        </div>
      ) : (
        <>
          {/* Summary */}
          <div className="grid grid-cols-3 gap-4">
            <div className="ft-card p-5 bg-emerald-50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800/40">
              <p className="text-xs text-muted-foreground">Receitas</p>
              <p className="text-xl font-bold text-emerald-600 number-display">
                +{formatCurrency(reportData.income)}
              </p>
            </div>
            <div className="ft-card p-5 bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-800/40">
              <p className="text-xs text-muted-foreground">Despesas</p>
              <p className="text-xl font-bold text-red-600 number-display">
                -{formatCurrency(reportData.expenses)}
              </p>
            </div>
            <div className="ft-card p-5">
              <p className="text-xs text-muted-foreground">Saldo do período</p>
              <p className={cn(
                'text-xl font-bold number-display',
                balance >= 0 ? 'text-emerald-600' : 'text-red-600'
              )}>
                {formatCurrency(balance)}
              </p>
            </div>
          </div>

          {/* Bar chart */}
          {reportData.categorySpending.length > 0 && (
            <div className="ft-card p-6">
              <h3 className="text-base font-semibold mb-4">Gastos por Categoria</h3>
              <ResponsiveContainer width="100%" height={260}>
                <BarChart
                  data={reportData.categorySpending}
                  margin={{ left: 0, right: 0, top: 4, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                  <XAxis
                    dataKey="category_name"
                    tick={{ fontSize: 11 }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <YAxis
                    tickFormatter={(v) => `R$${(v / 1000).toFixed(0)}k`}
                    tick={{ fontSize: 11 }}
                    axisLine={false}
                    tickLine={false}
                    width={50}
                  />
                  <Tooltip formatter={(v: any) => [formatCurrency(v), 'Valor']} />
                  <Bar dataKey="amount" name="Valor" radius={[4, 4, 0, 0]} fill="#6366f1" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Transactions table */}
          <div className="ft-card">
            <div className="p-6 border-b border-border flex items-center justify-between">
              <h3 className="text-base font-semibold">
                Transações ({reportData.transactions.length})
              </h3>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={exportCSV} className="gap-2">
                  <Download className="h-3.5 w-3.5" />
                  CSV
                </Button>
                <Button variant="outline" size="sm" onClick={exportJSON} className="gap-2">
                  <FileText className="h-3.5 w-3.5" />
                  JSON
                </Button>
              </div>
            </div>
            <div className="divide-y divide-border max-h-[400px] overflow-y-auto">
              {reportData.transactions.map((tx) => (
                <div
                  key={tx.id}
                  className="flex items-center gap-4 px-6 py-3 text-sm hover:bg-accent/30"
                >
                  <span className="text-muted-foreground w-24 shrink-0">
                    {formatDate(tx.date)}
                  </span>
                  <span className="flex-1 font-medium truncate">{tx.description}</span>
                  <span className="text-muted-foreground shrink-0">{tx.category?.name}</span>
                  <span className={cn(
                    'font-semibold number-display shrink-0',
                    tx.type === 'income'
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : 'text-red-600 dark:text-red-400'
                  )}>
                    {tx.type === 'income' ? '+' : '-'}{formatCurrency(tx.amount)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  )
}
