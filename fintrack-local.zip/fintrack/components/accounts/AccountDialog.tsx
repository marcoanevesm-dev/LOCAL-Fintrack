'use client'

import { useEffect } from 'react'
import { useForm, Controller } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { CATEGORY_COLORS, cn } from '@/utils'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import type { Account, AccountFormData, AccountType } from '@/types'

const schema = z.object({
  name: z.string().min(1, 'Nome obrigatório'),
  type: z.enum(['checking', 'savings', 'wallet', 'credit_card', 'investment']),
  balance: z.number({ coerce: true }),
  color: z.string(),
  icon: z.string().default('wallet'),
  bank_name: z.string().optional(),
})

type FormData = z.infer<typeof schema>

const ACCOUNT_TYPES: { value: AccountType; label: string }[] = [
  { value: 'checking', label: 'Conta Corrente' },
  { value: 'savings', label: 'Poupança' },
  { value: 'wallet', label: 'Carteira' },
  { value: 'credit_card', label: 'Cartão de Crédito' },
  { value: 'investment', label: 'Investimento' },
]

interface Props {
  open: boolean
  onClose: () => void
  onSave: (data: AccountFormData) => Promise<void>
  account?: Account | null
}

export function AccountDialog({ open, onClose, onSave, account }: Props) {
  const isEdit = !!account

  const {
    register, handleSubmit, reset, watch, setValue, control,
    formState: { errors, isSubmitting },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { color: '#6366f1', type: 'checking', balance: 0, icon: 'wallet' },
  })

  const selectedColor = watch('color')

  useEffect(() => {
    if (!open) return
    if (account) {
      reset({
        name: account.name,
        type: account.type,
        balance: account.balance,
        color: account.color,
        icon: account.icon,
        bank_name: account.bank_name ?? '',
      })
    } else {
      reset({ color: '#6366f1', type: 'checking', balance: 0, icon: 'wallet' })
    }
  }, [account, open, reset])

  const onSubmit = async (data: FormData) => {
    await onSave(data as AccountFormData)
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[440px]">
        <DialogHeader>
          <DialogTitle>{isEdit ? 'Editar' : 'Nova'} Conta</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-1.5">
            <Label>Nome da conta</Label>
            <Input placeholder="Ex: Nubank, Bradesco..." {...register('name')} />
            {errors.name && <p className="text-xs text-destructive">{errors.name.message}</p>}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Tipo</Label>
              <Controller
                control={control}
                name="type"
                render={({ field }) => (
                  <Select value={field.value} onValueChange={field.onChange}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {ACCOUNT_TYPES.map((t) => (
                        <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Saldo inicial (R$)</Label>
              <Input type="number" step="0.01" {...register('balance')} />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>Banco / Instituição (opcional)</Label>
            <Input placeholder="Ex: Banco do Brasil" {...register('bank_name')} />
          </div>

          {/* Color picker */}
          <div className="space-y-1.5">
            <Label>Cor</Label>
            <div className="flex flex-wrap gap-2">
              {CATEGORY_COLORS.slice(0, 12).map((color) => (
                <button
                  key={color}
                  type="button"
                  onClick={() => setValue('color', color)}
                  className={cn(
                    'w-7 h-7 rounded-full transition-all',
                    selectedColor === color && 'ring-2 ring-offset-2 ring-foreground scale-110'
                  )}
                  style={{ background: color }}
                />
              ))}
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Salvando...' : isEdit ? 'Salvar' : 'Criar'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
