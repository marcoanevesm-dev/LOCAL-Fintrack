'use client'

import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { useTransactions } from '@/hooks'
import { useUIStore } from '@/store'
import { formatCurrency, formatDate, getCurrentMonthRange } from '@/utils'
import { cn } from '@/utils'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'

export function RecentTransactions() {
  const { start, end } = getCurrentMonthRange()
  const { transactions, isLoading } = useTransactions({ start_date: start, end_date: end })
  const { showBalances } = useUIStore()

  const recent = transactions.slice(0, 8)

  return (
    <div className="ft-card p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-base font-semibold">Últimas Transações</h3>
          <p className="text-xs text-muted-foreground mt-1">Este mês</p>
        </div>
        <Button variant="ghost" size="sm" asChild>
          <Link href="/transactions" className="flex items-center gap-1 text-xs">
            Ver todas <ArrowRight className="h-3 w-3" />
          </Link>
        </Button>
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="flex items-center gap-3">
              <Skeleton className="h-9 w-9 rounded-lg" />
              <div className="flex-1 space-y-1.5">
                <Skeleton className="h-3.5 w-32" />
                <Skeleton className="h-3 w-20" />
              </div>
              <Skeleton className="h-4 w-20" />
            </div>
          ))}
        </div>
      ) : recent.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground text-sm">
          Nenhuma transação este mês
        </div>
      ) : (
        <div className="space-y-1">
          {recent.map((tx) => (
            <div
              key={tx.id}
              className="flex items-center gap-3 p-2 rounded-lg hover:bg-accent/50 transition-colors"
            >
              {/* Category dot */}
              <div
                className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0"
                style={{ background: tx.category?.color + '22', border: `1.5px solid ${tx.category?.color}44` }}
              >
                <span
                  className="w-2.5 h-2.5 rounded-full"
                  style={{ background: tx.category?.color }}
                />
              </div>

              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{tx.description}</p>
                <p className="text-xs text-muted-foreground">
                  {tx.category?.name} · {formatDate(tx.date)}
                </p>
              </div>

              <div className="text-right shrink-0">
                <p className={cn(
                  'text-sm font-semibold number-display',
                  tx.type === 'income'
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : 'text-red-600 dark:text-red-400'
                )}>
                  {tx.type === 'income' ? '+' : '-'}
                  {showBalances ? formatCurrency(tx.amount) : '••••'}
                </p>
                <p className="text-xs text-muted-foreground">{tx.account?.name}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
