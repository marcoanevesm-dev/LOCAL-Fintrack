'use client'

import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { useState, useEffect } from 'react'
import { getBudgets } from '@/services/budgets'
import { useAuthStore } from '@/store'
import { formatCurrency, calculatePercentage } from '@/utils'
import { Button } from '@/components/ui/button'
import { cn } from '@/utils'

export function BudgetOverview() {
  const { user } = useAuthStore()
  const [budgets, setBudgets] = useState<any[]>([])
  const now = new Date()

  useEffect(() => {
    if (!user) return
    getBudgets(user.user_id, now.getMonth() + 1, now.getFullYear())
      .then(setBudgets)
      .catch(console.error)
  }, [user])

  const top = budgets.slice(0, 4)

  return (
    <div className="ft-card p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-base font-semibold">Orçamentos</h3>
          <p className="text-xs text-muted-foreground mt-1">
            {now.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}
          </p>
        </div>
        <Button variant="ghost" size="sm" asChild>
          <Link href="/budgets" className="flex items-center gap-1 text-xs">
            Ver todos <ArrowRight className="h-3 w-3" />
          </Link>
        </Button>
      </div>

      {top.length === 0 ? (
        <div className="text-center py-6 text-muted-foreground text-sm">
          Nenhum orçamento configurado
        </div>
      ) : (
        <div className="space-y-3">
          {top.map((budget) => {
            const pct = calculatePercentage(budget.spent, budget.amount)
            const isAlert = pct >= budget.alert_threshold
            const isOver = pct >= 100

            return (
              <div key={budget.id} className="space-y-1.5">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <span
                      className="w-2 h-2 rounded-full"
                      style={{ background: budget.category?.color }}
                    />
                    <span className="font-medium">{budget.category?.name}</span>
                    {isAlert && !isOver && (
                      <span className="text-[10px] bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 px-1.5 py-0.5 rounded-full">
                        Atenção
                      </span>
                    )}
                    {isOver && (
                      <span className="text-[10px] bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400 px-1.5 py-0.5 rounded-full">
                        Excedido
                      </span>
                    )}
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {formatCurrency(budget.spent)} / {formatCurrency(budget.amount)}
                  </span>
                </div>
                <div className="progress-bar">
                  <div
                    className={cn(
                      'progress-fill',
                      isOver ? 'bg-red-500' : isAlert ? 'bg-amber-500' : 'bg-primary'
                    )}
                    style={{ width: `${Math.min(pct, 100)}%` }}
                  />
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
