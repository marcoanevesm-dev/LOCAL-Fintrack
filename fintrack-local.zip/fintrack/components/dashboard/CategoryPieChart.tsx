'use client'

import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts'
import { formatCurrency, formatPercent } from '@/utils'
import type { CategorySpending } from '@/types'

interface Props {
  data: CategorySpending[]
}

const CustomTooltip = ({ active, payload }: any) => {
  if (!active || !payload?.length) return null
  const item = payload[0].payload
  return (
    <div className="bg-card border border-border rounded-lg p-3 shadow-lg">
      <div className="flex items-center gap-2 mb-1">
        <span className="w-2 h-2 rounded-full" style={{ background: item.color }} />
        <span className="text-sm font-medium">{item.category_name}</span>
      </div>
      <p className="text-sm font-bold">{formatCurrency(item.amount)}</p>
      <p className="text-xs text-muted-foreground">{formatPercent(item.percentage)}</p>
    </div>
  )
}

const RADIAN = Math.PI / 180
const renderLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percentage }: any) => {
  if (percentage < 8) return null
  const radius = innerRadius + (outerRadius - innerRadius) * 0.5
  const x = cx + radius * Math.cos(-midAngle * RADIAN)
  const y = cy + radius * Math.sin(-midAngle * RADIAN)
  return (
    <text x={x} y={y} fill="white" textAnchor="middle" dominantBaseline="central" fontSize={11} fontWeight="600">
      {`${percentage.toFixed(0)}%`}
    </text>
  )
}

export function CategoryPieChart({ data }: Props) {
  const topCategories = data.slice(0, 6)

  return (
    <div className="ft-card p-6 h-full">
      <div className="mb-4">
        <h3 className="text-base font-semibold">Gastos por Categoria</h3>
        <p className="text-xs text-muted-foreground mt-1">Este mês</p>
      </div>

      {data.length === 0 ? (
        <div className="flex items-center justify-center h-40 text-muted-foreground text-sm">
          Sem gastos registrados
        </div>
      ) : (
        <>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie
                data={topCategories}
                dataKey="amount"
                nameKey="category_name"
                cx="50%"
                cy="50%"
                outerRadius={80}
                innerRadius={40}
                labelLine={false}
                label={renderLabel}
              >
                {topCategories.map((entry, i) => (
                  <Cell key={entry.category_id} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
            </PieChart>
          </ResponsiveContainer>

          {/* Legend */}
          <div className="mt-4 space-y-2">
            {topCategories.map((cat) => (
              <div key={cat.category_id} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <span
                    className="w-2.5 h-2.5 rounded-full shrink-0"
                    style={{ background: cat.color }}
                  />
                  <span className="text-muted-foreground truncate max-w-[100px]">
                    {cat.category_name}
                  </span>
                </div>
                <span className="font-medium tabular-nums">{formatCurrency(cat.amount)}</span>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  )
}
