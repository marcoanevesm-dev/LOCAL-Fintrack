import { AlertTriangle, CheckCircle, Info, Lightbulb } from 'lucide-react'
import { cn } from '@/utils'
import type { FinancialInsight } from '@/types'

interface Props {
  insights: FinancialInsight[]
}

const INSIGHT_CONFIG = {
  warning: {
    icon: AlertTriangle,
    color: 'text-amber-600 dark:text-amber-400',
    bg: 'bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800/40',
  },
  success: {
    icon: CheckCircle,
    color: 'text-emerald-600 dark:text-emerald-400',
    bg: 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800/40',
  },
  info: {
    icon: Info,
    color: 'text-blue-600 dark:text-blue-400',
    bg: 'bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800/40',
  },
  tip: {
    icon: Lightbulb,
    color: 'text-violet-600 dark:text-violet-400',
    bg: 'bg-violet-50 dark:bg-violet-950/30 border-violet-200 dark:border-violet-800/40',
  },
}

export function InsightsPanel({ insights }: Props) {
  return (
    <div className="ft-card p-6 h-full">
      <div className="mb-4">
        <h3 className="text-base font-semibold">Inteligência Financeira</h3>
        <p className="text-xs text-muted-foreground mt-1">Análise automática das suas finanças</p>
      </div>
      <div className="space-y-3">
        {insights.map((insight, i) => {
          const config = INSIGHT_CONFIG[insight.type]
          const Icon = config.icon
          return (
            <div
              key={i}
              className={cn(
                'flex gap-3 p-3 rounded-lg border text-sm',
                config.bg
              )}
            >
              <Icon className={cn('h-4 w-4 mt-0.5 shrink-0', config.color)} />
              <div>
                <p className="font-medium text-foreground leading-snug">{insight.title}</p>
                <p className="text-muted-foreground mt-0.5 leading-relaxed text-xs">
                  {insight.description}
                </p>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
