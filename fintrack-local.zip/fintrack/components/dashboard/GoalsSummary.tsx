'use client'

import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { useGoals } from '@/hooks'
import { formatCurrency, calculatePercentage } from '@/utils'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'

export function GoalsSummary() {
  const { goals } = useGoals()
  const activeGoals = goals.filter((g) => g.status === 'active').slice(0, 3)

  return (
    <div className="ft-card p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-base font-semibold">Metas Financeiras</h3>
          <p className="text-xs text-muted-foreground mt-1">
            {activeGoals.length} meta{activeGoals.length !== 1 ? 's' : ''} ativa{activeGoals.length !== 1 ? 's' : ''}
          </p>
        </div>
        <Button variant="ghost" size="sm" asChild>
          <Link href="/goals" className="flex items-center gap-1 text-xs">
            Ver todas <ArrowRight className="h-3 w-3" />
          </Link>
        </Button>
      </div>

      {activeGoals.length === 0 ? (
        <div className="text-center py-6 text-muted-foreground text-sm">
          Nenhuma meta ativa
        </div>
      ) : (
        <div className="space-y-4">
          {activeGoals.map((goal) => {
            const pct = calculatePercentage(goal.current_amount, goal.target_amount)
            return (
              <div key={goal.id} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span
                      className="w-2.5 h-2.5 rounded-full shrink-0"
                      style={{ background: goal.color }}
                    />
                    <span className="text-sm font-medium">{goal.name}</span>
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {pct.toFixed(0)}%
                  </span>
                </div>
                <Progress value={pct} className="h-1.5" style={{
                  '--progress-color': goal.color,
                } as React.CSSProperties} />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>{formatCurrency(goal.current_amount)}</span>
                  <span>{formatCurrency(goal.target_amount)}</span>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
