import { cn } from '@/utils'
import { ReactNode } from 'react'

interface StatCardProps {
  title: string
  value: string
  icon: ReactNode
  subtitle?: string
  highlight?: boolean
  className?: string
}

export function StatCard({ title, value, icon, subtitle, highlight, className }: StatCardProps) {
  return (
    <div className={cn('stat-card', className)}>
      <div className="flex items-start justify-between">
        <div className="flex flex-col gap-1">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
            {title}
          </p>
          <p className={cn(
            'text-2xl font-bold number-display tracking-tight',
            highlight && 'text-emerald-600 dark:text-emerald-400'
          )}>
            {value}
          </p>
        </div>
        <div className="p-2 rounded-lg bg-background/60">
          {icon}
        </div>
      </div>
      {subtitle && (
        <p className="text-xs text-muted-foreground">{subtitle}</p>
      )}
    </div>
  )
}
