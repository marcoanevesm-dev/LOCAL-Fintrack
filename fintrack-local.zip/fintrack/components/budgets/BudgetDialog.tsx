'use client'

import { useEffect } from 'react'
import { useForm, Controller } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { getMonthName } from '@/utils'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import type { Budget, BudgetFormData, Category } from '@/types'

const schema = z.object({
  category_id: z.string().min(1, 'Categoria obrigatória'),
  amount: z.number({ coerce: true }).positive('Valor deve ser positivo'),
  alert_threshold: z.number({ coerce: true }).min(1).max(100).default(80),
})

type FormData = z.infer<typeof schema>

interface Props {
  open: boolean
  onClose: () => void
  onSave: (data: BudgetFormData) => Promise<void>
  budget?: Budget | null
  categories: Category[]
  month: number
  year: number
}

export function BudgetDialog({ open, onClose, onSave, budget, categories, month, year }: Props) {
  const isEdit = !!budget

  const {
    register, handleSubmit, reset, control,
    formState: { errors, isSubmitting },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { alert_threshold: 80 },
  })

  useEffect(() => {
    if (!open) return
    if (budget) {
      reset({
        category_id: budget.category_id,
        amount: budget.amount,
        alert_threshold: budget.alert_threshold,
      })
    } else {
      reset({ alert_threshold: 80 })
    }
  }, [budget, open, reset])

  const onSubmit = async (data: FormData) => {
    await onSave({ ...data, month, year } as BudgetFormData)
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[400px]">
        <DialogHeader>
          <DialogTitle>
            {isEdit ? 'Editar' : 'Novo'} Orçamento — {getMonthName(month)} {year}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-1.5">
            <Label>Categoria</Label>
            <Controller
              control={control}
              name="category_id"
              render={({ field }) => (
                <Select value={field.value ?? ''} onValueChange={field.onChange}>
                  <SelectTrigger className={errors.category_id ? 'border-destructive' : ''}>
                    <SelectValue placeholder="Selecionar categoria..." />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        <div className="flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full" style={{ background: c.color }} />
                          {c.name}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            />
            {errors.category_id && (
              <p className="text-xs text-destructive">{errors.category_id.message}</p>
            )}
          </div>

          <div className="space-y-1.5">
            <Label>Limite mensal (R$)</Label>
            <Input type="number" step="0.01" placeholder="0,00" {...register('amount')} />
            {errors.amount && (
              <p className="text-xs text-destructive">{errors.amount.message}</p>
            )}
          </div>

          <div className="space-y-1.5">
            <Label>Alertar ao atingir (%)</Label>
            <Input type="number" min={1} max={100} {...register('alert_threshold')} />
            <p className="text-xs text-muted-foreground">
              Você receberá um alerta ao usar esse percentual do orçamento
            </p>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Salvando...' : isEdit ? 'Salvar' : 'Criar'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
