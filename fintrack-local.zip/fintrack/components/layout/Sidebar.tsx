'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  LayoutDashboard, ArrowLeftRight, Wallet, CreditCard,
  Target, PieChart, TrendingUp, BarChart3, Settings,
  LogOut, ChevronLeft, Eye, EyeOff, Bell,
} from 'lucide-react'
import { cn, formatCurrency, getInitials } from '@/utils'
import { useAuth } from '@/hooks'
import { useUIStore, useAccountStore, useNotificationStore } from '@/store'
import { getTotalBalance } from '@/services/accounts'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'

const NAV_ITEMS = [
  { label: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { label: 'Transações', href: '/transactions', icon: ArrowLeftRight },
  { label: 'Contas', href: '/accounts', icon: Wallet },
  { label: 'Cartões', href: '/credit-cards', icon: CreditCard },
  { label: 'Orçamentos', href: '/budgets', icon: PieChart },
  { label: 'Metas', href: '/goals', icon: Target },
  { label: 'Investimentos', href: '/investments', icon: TrendingUp },
  { label: 'Relatórios', href: '/reports', icon: BarChart3 },
]

export function Sidebar() {
  const pathname = usePathname()
  const { user, signOut } = useAuth()
  const { sidebarOpen, toggleSidebar, showBalances, toggleBalances } = useUIStore()
  const { accounts } = useAccountStore()
  const { unreadCount } = useNotificationStore()
  const totalBalance = getTotalBalance(accounts)

  return (
    <TooltipProvider delayDuration={300}>
      <aside
        className={cn(
          'flex flex-col h-screen bg-card border-r border-border transition-all duration-300 ease-in-out',
          sidebarOpen ? 'w-[260px]' : 'w-[72px]'
        )}
      >
        {/* Logo + Toggle */}
        <div className="flex items-center justify-between px-4 h-16 border-b border-border">
          {sidebarOpen && (
            <Link href="/dashboard" className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
                <TrendingUp className="w-4 h-4 text-white" />
              </div>
              <span className="font-bold text-lg gradient-text">FinTrack</span>
            </Link>
          )}
          {!sidebarOpen && (
            <Link href="/dashboard" className="mx-auto">
              <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
                <TrendingUp className="w-4 h-4 text-white" />
              </div>
            </Link>
          )}
          {sidebarOpen && (
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 ml-auto"
              onClick={toggleSidebar}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
          )}
        </div>

        {/* Balance widget */}
        {sidebarOpen && (
          <div className="mx-4 mt-4 p-4 rounded-xl bg-gradient-to-br from-indigo-600 to-violet-700 text-white">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-medium text-indigo-200">Saldo total</span>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6 text-indigo-200 hover:text-white hover:bg-white/20"
                onClick={toggleBalances}
              >
                {showBalances ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />}
              </Button>
            </div>
            <p className="text-xl font-bold number-display">
              {showBalances ? formatCurrency(totalBalance) : '••••••'}
            </p>
            <p className="text-xs text-indigo-200 mt-1">
              {accounts.length} conta{accounts.length !== 1 ? 's' : ''} ativas
            </p>
          </div>
        )}

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
          {!sidebarOpen && (
            <div className="flex justify-center mb-2">
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={toggleSidebar}
              >
                <ChevronLeft className="h-4 w-4 rotate-180" />
              </Button>
            </div>
          )}

          {NAV_ITEMS.map((item) => {
            const isActive = pathname === item.href ||
              (item.href !== '/dashboard' && pathname.startsWith(item.href))
            const Icon = item.icon

            if (!sidebarOpen) {
              return (
                <Tooltip key={item.href}>
                  <TooltipTrigger asChild>
                    <Link
                      href={item.href}
                      className={cn(
                        'sidebar-item justify-center',
                        isActive && 'sidebar-item-active'
                      )}
                    >
                      <Icon className="h-5 w-5 shrink-0" />
                    </Link>
                  </TooltipTrigger>
                  <TooltipContent side="right">{item.label}</TooltipContent>
                </Tooltip>
              )
            }

            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  'sidebar-item',
                  isActive && 'sidebar-item-active'
                )}
              >
                <Icon className="h-5 w-5 shrink-0" />
                <span>{item.label}</span>
              </Link>
            )
          })}
        </nav>

        <Separator />

        {/* Bottom: Notifications + Settings + User */}
        <div className="p-3 space-y-1">
          {sidebarOpen ? (
            <>
              <Link
                href="/settings"
                className={cn('sidebar-item', pathname === '/settings' && 'sidebar-item-active')}
              >
                <div className="relative">
                  <Bell className="h-5 w-5 shrink-0" />
                  {unreadCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-4 h-4 bg-destructive text-white text-[10px] rounded-full flex items-center justify-center">
                      {unreadCount > 9 ? '9+' : unreadCount}
                    </span>
                  )}
                </div>
                <span>Notificações</span>
                {unreadCount > 0 && (
                  <Badge variant="destructive" className="ml-auto text-xs h-5">
                    {unreadCount}
                  </Badge>
                )}
              </Link>
              <Link
                href="/settings"
                className={cn('sidebar-item', pathname === '/settings' && 'sidebar-item-active')}
              >
                <Settings className="h-5 w-5 shrink-0" />
                <span>Configurações</span>
              </Link>
            </>
          ) : (
            <>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link href="/settings" className="sidebar-item justify-center">
                    <Bell className="h-5 w-5" />
                  </Link>
                </TooltipTrigger>
                <TooltipContent side="right">Notificações</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link href="/settings" className="sidebar-item justify-center">
                    <Settings className="h-5 w-5" />
                  </Link>
                </TooltipTrigger>
                <TooltipContent side="right">Configurações</TooltipContent>
              </Tooltip>
            </>
          )}

          <Separator className="my-2" />

          {/* User */}
          {sidebarOpen ? (
            <div className="flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-accent cursor-pointer group">
              <Avatar className="h-8 w-8">
                <AvatarImage src={user?.avatar_url} />
                <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                  {getInitials(user?.name || 'U')}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{user?.name || 'Usuário'}</p>
                <p className="text-xs text-muted-foreground truncate">{user?.email}</p>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={signOut}
              >
                <LogOut className="h-3.5 w-3.5" />
              </Button>
            </div>
          ) : (
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  onClick={signOut}
                  className="sidebar-item justify-center w-full"
                >
                  <Avatar className="h-7 w-7">
                    <AvatarFallback className="bg-primary text-primary-foreground text-[10px]">
                      {getInitials(user?.name || 'U')}
                    </AvatarFallback>
                  </Avatar>
                </button>
              </TooltipTrigger>
              <TooltipContent side="right">Sair</TooltipContent>
            </Tooltip>
          )}
        </div>
      </aside>
    </TooltipProvider>
  )
}
