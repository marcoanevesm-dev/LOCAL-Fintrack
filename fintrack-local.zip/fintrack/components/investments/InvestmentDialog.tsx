'use client'

import { useEffect } from 'react'
import { useForm, Controller } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import type { Investment, InvestmentType } from '@/types'

const schema = z.object({
  name: z.string().min(1, 'Nome obrigatório'),
  ticker: z.string().optional(),
  type: z.enum(['stocks', 'fii', 'treasury', 'cdb', 'crypto', 'other']),
  quantity: z.number({ coerce: true }).min(0),
  average_price: z.number({ coerce: true }).min(0),
  current_price: z.number({ coerce: true }).min(0),
  invested_amount: z.number({ coerce: true }).min(0),
  current_value: z.number({ coerce: true }).min(0),
  profitability: z.number({ coerce: true }).default(0),
  broker: z.string().optional(),
})

type FormData = z.infer<typeof schema>

type InvestmentPayload = Omit<Investment, 'id' | 'user_id' | 'created_at' | 'updated_at'>

const TYPES: { value: InvestmentType; label: string }[] = [
  { value: 'stocks', label: 'Ações' },
  { value: 'fii', label: 'FIIs' },
  { value: 'treasury', label: 'Tesouro Direto' },
  { value: 'cdb', label: 'CDB' },
  { value: 'crypto', label: 'Criptomoedas' },
  { value: 'other', label: 'Outros' },
]

interface Props {
  open: boolean
  onClose: () => void
  onSave: (data: InvestmentPayload) => Promise<void>
  investment?: Investment | null
}

export function InvestmentDialog({ open, onClose, onSave, investment }: Props) {
  const isEdit = !!investment

  const {
    register, handleSubmit, reset, control,
    formState: { errors, isSubmitting },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      type: 'stocks',
      quantity: 0,
      average_price: 0,
      current_price: 0,
      invested_amount: 0,
      current_value: 0,
      profitability: 0,
    },
  })

  useEffect(() => {
    if (!open) return
    if (investment) {
      reset({
        name: investment.name,
        ticker: investment.ticker ?? '',
        type: investment.type,
        quantity: investment.quantity,
        average_price: investment.average_price,
        current_price: investment.current_price,
        invested_amount: investment.invested_amount,
        current_value: investment.current_value,
        profitability: investment.profitability,
        broker: investment.broker ?? '',
      })
    } else {
      reset({
        type: 'stocks',
        quantity: 0,
        average_price: 0,
        current_price: 0,
        invested_amount: 0,
        current_value: 0,
        profitability: 0,
      })
    }
  }, [investment, open, reset])

  const onSubmit = async (data: FormData) => {
    await onSave(data as InvestmentPayload)
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>{isEdit ? 'Editar' : 'Novo'} Investimento</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Nome</Label>
              <Input placeholder="Ex: Petrobras, Bitcoin..." {...register('name')} />
              {errors.name && <p className="text-xs text-destructive">{errors.name.message}</p>}
            </div>
            <div className="space-y-1.5">
              <Label>Ticker (opcional)</Label>
              <Input placeholder="Ex: PETR4, BTC" {...register('ticker')} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Tipo</Label>
              <Controller
                control={control}
                name="type"
                render={({ field }) => (
                  <Select value={field.value} onValueChange={field.onChange}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {TYPES.map((t) => (
                        <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Corretora (opcional)</Label>
              <Input placeholder="Ex: XP, Rico, NuInvest..." {...register('broker')} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Quantidade</Label>
              <Input type="number" step="0.00000001" {...register('quantity')} />
            </div>
            <div className="space-y-1.5">
              <Label>Preço médio (R$)</Label>
              <Input type="number" step="0.000001" {...register('average_price')} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Preço atual (R$)</Label>
              <Input type="number" step="0.000001" {...register('current_price')} />
            </div>
            <div className="space-y-1.5">
              <Label>Total investido (R$)</Label>
              <Input type="number" step="0.01" {...register('invested_amount')} />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>Valor atual (R$)</Label>
            <Input type="number" step="0.01" {...register('current_value')} />
            <p className="text-xs text-muted-foreground">
              Rentabilidade será calculada automaticamente
            </p>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Salvando...' : isEdit ? 'Salvar' : 'Cadastrar'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
