'use client'

import { useState } from 'react'
import { formatCurrency, calculatePercentage } from '@/utils'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import type { Goal } from '@/types'

interface Props {
  open: boolean
  goal: Goal
  onClose: () => void
  onConfirm: (amount: number) => Promise<void>
}

export function GoalContributeDialog({ open, goal, onClose, onConfirm }: Props) {
  const [amount, setAmount] = useState('')
  const [loading, setLoading] = useState(false)

  const remaining = goal.target_amount - goal.current_amount
  const pct = calculatePercentage(goal.current_amount, goal.target_amount)

  const handle = async () => {
    const val = parseFloat(amount)
    if (!val || val <= 0) return
    setLoading(true)
    await onConfirm(Math.min(val, remaining))
    setLoading(false)
    setAmount('')
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[380px]">
        <DialogHeader>
          <DialogTitle>Contribuir para "{goal.name}"</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="p-4 rounded-lg bg-muted space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Progresso atual</span>
              <span className="font-medium">{pct.toFixed(1)}%</span>
            </div>
            <div className="progress-bar">
              <div
                className="progress-fill"
                style={{ width: `${pct}%`, background: goal.color }}
              />
            </div>
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>{formatCurrency(goal.current_amount)}</span>
              <span>Faltam {formatCurrency(remaining)}</span>
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>Valor a contribuir (R$)</Label>
            <Input
              type="number"
              step="0.01"
              placeholder="0,00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              max={remaining}
            />
            <p className="text-xs text-muted-foreground">
              Máximo: {formatCurrency(remaining)}
            </p>
          </div>

          {/* Quick amounts */}
          <div className="flex gap-2 flex-wrap">
            {[50, 100, 200, 500].filter((v) => v <= remaining).map((v) => (
              <Button
                key={v}
                type="button"
                variant="outline"
                size="sm"
                className="text-xs h-7"
                onClick={() => setAmount(String(v))}
              >
                R${v}
              </Button>
            ))}
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="text-xs h-7"
              onClick={() => setAmount(String(remaining.toFixed(2)))}
            >
              Completar
            </Button>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={handle} disabled={loading || !amount}>
            {loading ? 'Registrando...' : 'Confirmar'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
