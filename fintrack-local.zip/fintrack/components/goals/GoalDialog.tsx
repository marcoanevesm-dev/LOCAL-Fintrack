'use client'

import { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { CATEGORY_COLORS } from '@/utils'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { cn } from '@/utils'
import type { Goal, GoalFormData } from '@/types'

const schema = z.object({
  name: z.string().min(1, 'Nome obrigatório'),
  description: z.string().optional(),
  target_amount: z.number({ coerce: true }).positive(),
  current_amount: z.number({ coerce: true }).min(0),
  target_date: z.string().optional(),
  monthly_contribution: z.number({ coerce: true }).min(0).optional(),
  color: z.string(),
  icon: z.string().default('target'),
})

type FormData = z.infer<typeof schema>

interface Props {
  open: boolean
  onClose: () => void
  onSave: (data: GoalFormData) => Promise<void>
  goal?: Goal | null
}

const GOAL_EMOJIS = ['🎯', '🏠', '🚗', '✈️', '💰', '📱', '🎓', '💎', '🏖️', '🏋️', '🎸', '📚']

export function GoalDialog({ open, onClose, onSave, goal }: Props) {
  const isEdit = !!goal
  const { register, handleSubmit, reset, watch, setValue, formState: { errors, isSubmitting } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { color: '#6366f1', icon: '🎯', current_amount: 0 },
  })

  const selectedColor = watch('color')

  useEffect(() => {
    if (goal) {
      reset({
        name: goal.name,
        description: goal.description || '',
        target_amount: goal.target_amount,
        current_amount: goal.current_amount,
        target_date: goal.target_date || '',
        monthly_contribution: goal.monthly_contribution || undefined,
        color: goal.color,
        icon: goal.icon,
      })
    } else {
      reset({ color: '#6366f1', icon: '🎯', current_amount: 0 })
    }
  }, [goal, open])

  const onSubmit = async (data: FormData) => {
    await onSave(data as GoalFormData)
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[460px]">
        <DialogHeader>
          <DialogTitle>{isEdit ? 'Editar' : 'Nova'} Meta</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="space-y-1.5">
            <Label>Nome da meta</Label>
            <Input placeholder="Ex: Comprar um carro" {...register('name')} />
            {errors.name && <p className="text-xs text-destructive">{errors.name.message}</p>}
          </div>

          <div className="space-y-1.5">
            <Label>Descrição (opcional)</Label>
            <Textarea className="resize-none h-16" placeholder="Detalhes da meta..." {...register('description')} />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Valor alvo (R$)</Label>
              <Input type="number" step="0.01" {...register('target_amount')} />
            </div>
            <div className="space-y-1.5">
              <Label>Já tenho (R$)</Label>
              <Input type="number" step="0.01" {...register('current_amount')} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Data alvo (opcional)</Label>
              <Input type="date" {...register('target_date')} />
            </div>
            <div className="space-y-1.5">
              <Label>Contribuição mensal (R$)</Label>
              <Input type="number" step="0.01" {...register('monthly_contribution')} />
            </div>
          </div>

          {/* Emoji */}
          <div className="space-y-1.5">
            <Label>Ícone</Label>
            <div className="flex flex-wrap gap-2">
              {GOAL_EMOJIS.map((emoji) => (
                <button
                  key={emoji}
                  type="button"
                  onClick={() => setValue('icon', emoji)}
                  className={cn(
                    'w-9 h-9 rounded-lg flex items-center justify-center text-lg transition-all',
                    watch('icon') === emoji
                      ? 'bg-primary/20 ring-2 ring-primary'
                      : 'bg-muted hover:bg-accent'
                  )}
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>

          {/* Color */}
          <div className="space-y-1.5">
            <Label>Cor</Label>
            <div className="flex flex-wrap gap-2">
              {CATEGORY_COLORS.slice(0, 12).map((color) => (
                <button
                  key={color}
                  type="button"
                  onClick={() => setValue('color', color)}
                  className={cn(
                    'w-7 h-7 rounded-full transition-all',
                    selectedColor === color && 'ring-2 ring-offset-2 ring-foreground scale-110'
                  )}
                  style={{ background: color }}
                />
              ))}
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Salvando...' : isEdit ? 'Salvar' : 'Criar meta'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
