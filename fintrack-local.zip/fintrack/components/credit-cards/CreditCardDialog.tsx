'use client'

import { useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { CATEGORY_COLORS, cn } from '@/utils'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import type { CreditCard, CreditCardFormData } from '@/types'

const schema = z.object({
  name: z.string().min(1, 'Nome obrigatório'),
  bank_name: z.string().min(1, 'Banco obrigatório'),
  limit_amount: z.number({ coerce: true }).positive('Limite deve ser positivo'),
  closing_day: z.number({ coerce: true }).min(1).max(31),
  due_day: z.number({ coerce: true }).min(1).max(31),
  color: z.string(),
  last_four_digits: z.string().max(4).optional(),
})

type FormData = z.infer<typeof schema>

interface Props {
  open: boolean
  onClose: () => void
  onSave: (data: CreditCardFormData) => Promise<void>
  card?: CreditCard | null
}

export function CreditCardDialog({ open, onClose, onSave, card }: Props) {
  const isEdit = !!card

  const {
    register, handleSubmit, reset, watch, setValue,
    formState: { errors, isSubmitting },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { color: '#6366f1', closing_day: 1, due_day: 10 },
  })

  const selectedColor = watch('color')
  const cardName = watch('name')

  useEffect(() => {
    if (open) {
      if (card) {
        reset({
          name: card.name,
          bank_name: card.bank_name,
          limit_amount: card.limit_amount,
          closing_day: card.closing_day,
          due_day: card.due_day,
          color: card.color,
          last_four_digits: card.last_four_digits ?? '',
        })
      } else {
        reset({ color: '#6366f1', closing_day: 1, due_day: 10 })
      }
    }
  }, [card, open, reset])

  const onSubmit = async (data: FormData) => {
    await onSave(data as CreditCardFormData)
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[460px]">
        <DialogHeader>
          <DialogTitle>{isEdit ? 'Editar' : 'Novo'} Cartão</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Nome do cartão</Label>
              <Input placeholder="Ex: Nubank Gold" {...register('name')} />
              {errors.name && <p className="text-xs text-destructive">{errors.name.message}</p>}
            </div>
            <div className="space-y-1.5">
              <Label>Banco / Emissor</Label>
              <Input placeholder="Ex: Nubank, Itaú..." {...register('bank_name')} />
              {errors.bank_name && <p className="text-xs text-destructive">{errors.bank_name.message}</p>}
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>Limite (R$)</Label>
            <Input type="number" step="0.01" placeholder="5000,00" {...register('limit_amount')} />
            {errors.limit_amount && <p className="text-xs text-destructive">{errors.limit_amount.message}</p>}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Dia de fechamento</Label>
              <Input type="number" min={1} max={31} {...register('closing_day')} />
              {errors.closing_day && <p className="text-xs text-destructive">{errors.closing_day.message}</p>}
            </div>
            <div className="space-y-1.5">
              <Label>Dia de vencimento</Label>
              <Input type="number" min={1} max={31} {...register('due_day')} />
              {errors.due_day && <p className="text-xs text-destructive">{errors.due_day.message}</p>}
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>Últimos 4 dígitos (opcional)</Label>
            <Input placeholder="1234" maxLength={4} {...register('last_four_digits')} />
          </div>

          {/* Color picker */}
          <div className="space-y-1.5">
            <Label>Cor do cartão</Label>
            <div className="flex flex-wrap gap-2">
              {CATEGORY_COLORS.slice(0, 14).map((color) => (
                <button
                  key={color}
                  type="button"
                  onClick={() => setValue('color', color)}
                  className={cn(
                    'w-7 h-7 rounded-full transition-all',
                    selectedColor === color && 'ring-2 ring-offset-2 ring-foreground scale-110'
                  )}
                  style={{ background: color }}
                />
              ))}
            </div>
          </div>

          {/* Live preview */}
          <div
            className="h-14 rounded-xl flex items-center px-5 text-white font-bold text-sm"
            style={{
              background: `linear-gradient(135deg, ${selectedColor}, ${selectedColor}88)`,
            }}
          >
            <span>{cardName || 'Meu Cartão'}</span>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Salvando...' : isEdit ? 'Salvar' : 'Cadastrar'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
