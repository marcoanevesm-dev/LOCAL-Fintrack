'use client'

import { useEffect } from 'react'
import { useForm, Controller } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { createTransaction, updateTransaction } from '@/services/transactions'
import { useAuthStore } from '@/store'
import { useCategories, useAccounts } from '@/hooks'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Textarea } from '@/components/ui/textarea'
import { useToast } from '@/components/ui/use-toast'
import type { Transaction } from '@/types'

const schema = z.object({
  type: z.enum(['income', 'expense']),
  amount: z.number({ coerce: true }).positive('Valor deve ser positivo'),
  description: z.string().min(1, 'Descrição obrigatória'),
  date: z.string().min(1, 'Data obrigatória'),
  account_id: z.string().min(1, 'Conta obrigatória'),
  category_id: z.string().min(1, 'Categoria obrigatória'),
  payment_method: z.enum(['cash', 'debit', 'credit', 'pix', 'transfer', 'boleto']).optional(),
  notes: z.string().optional(),
  installments: z.number({ coerce: true }).min(1).max(48).optional(),
})

type FormData = z.infer<typeof schema>

interface Props {
  open: boolean
  onClose: () => void
  onSuccess: () => void
  transaction?: Transaction | null
}

export function TransactionDialog({ open, onClose, onSuccess, transaction }: Props) {
  const { user } = useAuthStore()
  const { incomeCategories, expenseCategories } = useCategories()
  const { accounts } = useAccounts()
  const { toast } = useToast()
  const isEdit = !!transaction

  const {
    register, handleSubmit, reset, watch, setValue, control,
    formState: { errors, isSubmitting },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      type: 'expense',
      date: new Date().toISOString().split('T')[0],
      installments: 1,
    },
  })

  const type = watch('type')
  const filteredCategories = type === 'income' ? incomeCategories : expenseCategories

  // Reset form whenever dialog opens or transaction changes
  useEffect(() => {
    if (!open) return
    if (transaction) {
      reset({
        type: transaction.type as 'income' | 'expense',
        amount: transaction.amount,
        description: transaction.description,
        date: transaction.date,
        account_id: transaction.account_id,
        category_id: transaction.category_id,
        payment_method: transaction.payment_method ?? undefined,
        notes: transaction.notes ?? '',
        installments: 1,
      })
    } else {
      reset({
        type: 'expense',
        date: new Date().toISOString().split('T')[0],
        installments: 1,
        amount: undefined as any,
        description: '',
        account_id: '',
        category_id: '',
        payment_method: undefined,
        notes: '',
      })
    }
  }, [transaction, open, reset])

  const onSubmit = async (data: FormData) => {
    if (!user) return
    try {
      if (isEdit) {
        await updateTransaction(transaction!.id, user.user_id, data)
        toast({ title: 'Transação atualizada' })
      } else {
        await createTransaction(user.user_id, data)
        toast({ title: 'Transação criada' })
      }
      onSuccess()
    } catch (e: any) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' })
    }
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[480px]">
        <DialogHeader>
          <DialogTitle>{isEdit ? 'Editar' : 'Nova'} Transação</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          {/* Type tabs */}
          <Tabs
            value={type}
            onValueChange={(v) => setValue('type', v as 'income' | 'expense')}
          >
            <TabsList className="w-full">
              <TabsTrigger value="expense" className="flex-1">Despesa</TabsTrigger>
              <TabsTrigger value="income" className="flex-1">Receita</TabsTrigger>
            </TabsList>
          </Tabs>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Valor (R$)</Label>
              <Input
                type="number"
                step="0.01"
                placeholder="0,00"
                {...register('amount')}
                className={errors.amount ? 'border-destructive' : ''}
              />
              {errors.amount && (
                <p className="text-xs text-destructive">{errors.amount.message}</p>
              )}
            </div>
            <div className="space-y-1.5">
              <Label>Data</Label>
              <Input type="date" {...register('date')} />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>Descrição</Label>
            <Input placeholder="Ex: Supermercado Extra" {...register('description')} />
            {errors.description && (
              <p className="text-xs text-destructive">{errors.description.message}</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            {/* Category — controlled so defaultValue works on edit */}
            <div className="space-y-1.5">
              <Label>Categoria</Label>
              <Controller
                control={control}
                name="category_id"
                render={({ field }) => (
                  <Select value={field.value} onValueChange={field.onChange}>
                    <SelectTrigger className={errors.category_id ? 'border-destructive' : ''}>
                      <SelectValue placeholder="Selecionar..." />
                    </SelectTrigger>
                    <SelectContent>
                      {filteredCategories.map((c) => (
                        <SelectItem key={c.id} value={c.id}>
                          <div className="flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full" style={{ background: c.color }} />
                            {c.name}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              />
              {errors.category_id && (
                <p className="text-xs text-destructive">{errors.category_id.message}</p>
              )}
            </div>

            {/* Account — controlled */}
            <div className="space-y-1.5">
              <Label>Conta</Label>
              <Controller
                control={control}
                name="account_id"
                render={({ field }) => (
                  <Select value={field.value} onValueChange={field.onChange}>
                    <SelectTrigger className={errors.account_id ? 'border-destructive' : ''}>
                      <SelectValue placeholder="Selecionar..." />
                    </SelectTrigger>
                    <SelectContent>
                      {accounts.map((a) => (
                        <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              />
              {errors.account_id && (
                <p className="text-xs text-destructive">{errors.account_id.message}</p>
              )}
            </div>
          </div>

          {/* Installments & payment method (expense only, new only) */}
          {type === 'expense' && !isEdit && (
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Parcelas</Label>
                <Input type="number" min={1} max={48} {...register('installments')} />
              </div>
              <div className="space-y-1.5">
                <Label>Forma de pagamento</Label>
                <Controller
                  control={control}
                  name="payment_method"
                  render={({ field }) => (
                    <Select value={field.value ?? ''} onValueChange={field.onChange}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecionar..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cash">Dinheiro</SelectItem>
                        <SelectItem value="debit">Débito</SelectItem>
                        <SelectItem value="credit">Crédito</SelectItem>
                        <SelectItem value="pix">PIX</SelectItem>
                        <SelectItem value="transfer">Transferência</SelectItem>
                        <SelectItem value="boleto">Boleto</SelectItem>
                      </SelectContent>
                    </Select>
                  )}
                />
              </div>
            </div>
          )}

          <div className="space-y-1.5">
            <Label>Observações (opcional)</Label>
            <Textarea
              placeholder="Notas adicionais..."
              className="resize-none h-20"
              {...register('notes')}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Salvando...' : isEdit ? 'Salvar' : 'Criar'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
