'use client'

type Row = Record<string, any>
const DB_KEY = 'fintrack_local_db_v1'
const SESSION_KEY = 'fintrack_local_session_v1'
const AUTH_EVENT = 'fintrack_auth_change'

const TABLES = ['profiles','accounts','categories','transactions','goals','budgets','credit_cards','investments'] as const

type DB = Record<(typeof TABLES)[number], Row[]>

function nowIso() { return new Date().toISOString() }
function id() { return crypto.randomUUID() }

function emptyDb(): DB {
  return { profiles: [], accounts: [], categories: [], transactions: [], goals: [], budgets: [], credit_cards: [], investments: [] }
}

function getDb(): DB {
  if (typeof window === 'undefined') return emptyDb()
  const raw = localStorage.getItem(DB_KEY)
  if (!raw) return emptyDb()
  try { return { ...emptyDb(), ...JSON.parse(raw) } } catch { return emptyDb() }
}
function setDb(db: DB) { if (typeof window !== 'undefined') localStorage.setItem(DB_KEY, JSON.stringify(db)) }
function getSession() { if (typeof window === 'undefined') return null; const raw=localStorage.getItem(SESSION_KEY); return raw?JSON.parse(raw):null }
function setSession(session:any) { if (typeof window === 'undefined') return; if (session) localStorage.setItem(SESSION_KEY, JSON.stringify(session)); else localStorage.removeItem(SESSION_KEY); window.dispatchEvent(new CustomEvent(AUTH_EVENT,{detail:session})) }

function attachRelations(table:string, rows:Row[]) {
  const db = getDb()
  return rows.map(r => {
    const row = { ...r }
    if (table === 'transactions') {
      row.account = db.accounts.find(a => a.id === r.account_id)
      row.category = db.categories.find(c => c.id === r.category_id)
    }
    if (table === 'budgets') {
      row.category = db.categories.find(c => c.id === r.category_id)
    }
    return row
  })
}

class QueryBuilder {
  table: keyof DB
  filters: ((row:Row)=>boolean)[] = []
  orders: {field:string, ascending:boolean}[] = []
  action: 'select'|'insert'|'update'|'delete' = 'select'
  payload: any = null
  withRelations = false
  one = false
  _limit?: number
  constructor(table:keyof DB){ this.table=table }
  select(spec?: string){ if (this.action === 'select') this.action='select'; this.withRelations=!!spec && spec.includes(':'); return this }
  insert(payload:any){ this.action='insert'; this.payload=payload; return this }
  update(payload:any){ this.action='update'; this.payload=payload; return this }
  delete(){ this.action='delete'; return this }
  eq(field:string, value:any){ this.filters.push(r=>r[field]===value); return this }
  gte(field:string, value:any){ this.filters.push(r=>r[field]>=value); return this }
  lte(field:string, value:any){ this.filters.push(r=>r[field]<=value); return this }
  ilike(field:string, pattern:string){ const q=pattern.replace(/%/g,'').toLowerCase(); this.filters.push(r=>String(r[field]||'').toLowerCase().includes(q)); return this }
  order(field:string, opts?:{ascending?:boolean}){ this.orders.push({field, ascending: opts?.ascending!==false}); return this }
  limit(n:number){ this._limit=n; return this }
  single(){ this.one=true; return this }
  then(resolve:any,reject?:any){ return this.execute().then(resolve,reject) }
  async execute(){
    const db = getDb(); let rows = [...db[this.table]]
    const applyFilters = () => { for (const f of this.filters) rows = rows.filter(f); if (this.orders.length) rows.sort((a,b)=>{ for (const o of this.orders){ if(a[o.field]===b[o.field]) continue; const cmp = a[o.field] > b[o.field] ? 1 : -1; return o.ascending ? cmp : -cmp } return 0 }); if (this._limit) rows = rows.slice(0,this._limit) }
    try {
      if (this.action==='select') {
        applyFilters();
        let out = this.withRelations ? attachRelations(this.table, rows) : rows.map(r=>({...r}))
        if (this.one) out = out[0] || null
        return { data: out, error: null }
      }
      if (this.action==='insert') {
        const items = Array.isArray(this.payload) ? this.payload : [this.payload]
        const inserted = items.map(item=>({ id:id(), created_at: nowIso(), updated_at: nowIso(), ...item }))
        db[this.table].push(...inserted); setDb(db)
        let out:any = this.withRelations ? attachRelations(this.table, inserted) : inserted
        if (this.one) out = out[0]
        return { data: out, error: null }
      }
      applyFilters()
      if (this.action==='update') {
        const updated:Row[]=[]
        db[this.table] = db[this.table].map(r=>{
          if (!rows.find(x=>x.id===r.id)) return r
          const nr={...r,...this.payload}
          updated.push(nr); return nr
        })
        setDb(db)
        let out:any = this.withRelations ? attachRelations(this.table, updated) : updated
        if (this.one) out = out[0]
        return { data: out, error: null }
      }
      if (this.action==='delete') {
        const ids = new Set(rows.map(r=>r.id)); db[this.table] = db[this.table].filter(r=>!ids.has(r.id)); setDb(db); return { data: null, error: null }
      }
      return { data:null,error:null }
    } catch (e:any) { return { data:null, error:e } }
  }
}

function authApi(){
  return {
    async getSession(){ const s=getSession(); return { data:{ session: s ? { user: s } : null } } },
    onAuthStateChange(cb:(event:string, session:any)=>void){
      const handler=(e:any)=>cb('SIGNED_IN', e.detail ? { user: e.detail } : null)
      if (typeof window !== 'undefined') window.addEventListener(AUTH_EVENT, handler)
      return { data:{ subscription:{ unsubscribe(){ if (typeof window !== 'undefined') window.removeEventListener(AUTH_EVENT, handler) } } } }
    },
    async signInWithPassword({email,password}:{email:string,password:string}){
      const db=getDb(); const profile=db.profiles.find(p=>p.email===email && p.password===password)
      if (!profile) return { error:{ message:'E-mail ou senha inválidos' } }
      setSession({ id: profile.user_id, email: profile.email })
      return { error:null }
    },
    async signUp({email,password,options}:{email:string,password:string,options?:any}){
      const db=getDb(); if (db.profiles.some(p=>p.email===email)) return { error:{message:'E-mail já cadastrado'} }
      const user_id=id();
      db.profiles.push({ id:id(), user_id, name: options?.data?.name || 'Usuário', email, password, currency:'BRL', locale:'pt-BR', created_at:nowIso(), updated_at:nowIso() })
      setDb(db); return { error:null }
    },
    async signOut(){ setSession(null); return { error:null } },
    async resetPasswordForEmail(){ return { error:null } },
    async updateUser({password}:{password:string}){ const s=getSession(); if(!s) return { error:{message:'Usuário não autenticado'} }; const db=getDb(); const p=db.profiles.find(x=>x.user_id===s.id); if(p){p.password=password; p.updated_at=nowIso(); setDb(db)} return { error:null } },
  }
}

export function createClient(){
  return { auth: authApi(), from(table:keyof DB){ return new QueryBuilder(table) } }
}
