import { useState, useEffect, useCallback } from 'react'
import { createClient } from '@/lib/supabase'
import {
  useAuthStore, useAccountStore, useCategoryStore,
  useTransactionStore, useGoalStore,
} from '@/store'
import { getAccounts } from '@/services/accounts'
import { getCategories, seedDefaultCategories } from '@/services/categories'
import { getTransactions, getMonthlyStats, getCategorySpending } from '@/services/transactions'
import { getGoals } from '@/services/goals'
import { getInvestments } from '@/services/investments'
import { getAccounts as getAccountsService } from '@/services/accounts'
import { getCurrentMonthRange, generateInsights } from '@/utils'
import type {
  DashboardSummary, MonthlyEvolution, CategorySpending, FinancialInsight,
  TransactionFilters,
} from '@/types'

// ============================================================
// useAuth
// ============================================================
export function useAuth() {
  const { user, isLoading, setUser, setLoading } = useAuthStore()
  const supabase = createClient()

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (session?.user) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('user_id', session.user.id)
          .single()
        setUser(profile ? { ...profile, email: session.user.email } : null)
      } else {
        setUser(null)
      }
      setLoading(false)
    })

    // Listen for changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (session?.user) {
          const { data: profile } = await supabase
            .from('profiles')
            .select('*')
            .eq('user_id', session.user.id)
            .single()
          setUser(profile ? { ...profile, email: session.user.email } : null)
        } else {
          setUser(null)
        }
        setLoading(false)
      }
    )
    return () => subscription.unsubscribe()
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  const signOut = useCallback(async () => {
    await supabase.auth.signOut()
  }, [supabase]) // eslint-disable-line react-hooks/exhaustive-deps

  return { user, isLoading, signOut }
}

// ============================================================
// useAccounts
// ============================================================
export function useAccounts() {
  const { user } = useAuthStore()
  const { accounts, setAccounts, isLoading, setLoading } = useAccountStore()

  const fetchAccounts = useCallback(async () => {
    if (!user) return
    setLoading(true)
    try {
      const data = await getAccounts(user.user_id)
      setAccounts(data)
    } finally {
      setLoading(false)
    }
  }, [user]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { fetchAccounts() }, [fetchAccounts])

  return { accounts, isLoading, refetch: fetchAccounts }
}

// ============================================================
// useCategories
// ============================================================
export function useCategories() {
  const { user } = useAuthStore()
  const { categories, setCategories, isLoading, setLoading } = useCategoryStore()

  const fetchCategories = useCallback(async () => {
    if (!user) return
    setLoading(true)
    try {
      await seedDefaultCategories(user.user_id)
      const data = await getCategories(user.user_id)
      setCategories(data)
    } finally {
      setLoading(false)
    }
  }, [user]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { fetchCategories() }, [fetchCategories])

  const incomeCategories = categories.filter((c) => c.type === 'income')
  const expenseCategories = categories.filter((c) => c.type === 'expense')

  return { categories, incomeCategories, expenseCategories, isLoading, refetch: fetchCategories }
}

// ============================================================
// useTransactions
// ============================================================
export function useTransactions(filters: TransactionFilters = {}) {
  const { user } = useAuthStore()
  const { transactions, setTransactions, isLoading, setLoading } = useTransactionStore()

  // Stable key so effect doesn't fire on every render
  const filterKey = JSON.stringify(filters)

  const fetchTransactions = useCallback(async () => {
    if (!user) return
    setLoading(true)
    try {
      const data = await getTransactions(user.user_id, filters)
      setTransactions(data)
    } finally {
      setLoading(false)
    }
  }, [user, filterKey]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { fetchTransactions() }, [fetchTransactions])

  return { transactions, isLoading, refetch: fetchTransactions }
}

// ============================================================
// useGoals
// ============================================================
export function useGoals() {
  const { user } = useAuthStore()
  const { goals, setGoals, isLoading, setLoading } = useGoalStore()

  const fetchGoals = useCallback(async () => {
    if (!user) return
    setLoading(true)
    try {
      const data = await getGoals(user.user_id)
      setGoals(data)
    } finally {
      setLoading(false)
    }
  }, [user]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { fetchGoals() }, [fetchGoals])

  return { goals, isLoading, refetch: fetchGoals }
}

// ============================================================
// useInvestments
// ============================================================
export function useInvestments() {
  const { user } = useAuthStore()
  const [investments, setInvestments] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(false)

  const fetchInvestments = useCallback(async () => {
    if (!user) return
    setIsLoading(true)
    try {
      const data = await getInvestments(user.user_id)
      setInvestments(data)
    } finally {
      setIsLoading(false)
    }
  }, [user])

  useEffect(() => { fetchInvestments() }, [fetchInvestments])

  return { investments, isLoading, refetch: fetchInvestments }
}

// ============================================================
// useDashboard
// ============================================================
export function useDashboard() {
  const { user } = useAuthStore()
  const [summary, setSummary] = useState<DashboardSummary | null>(null)
  const [evolution, setEvolution] = useState<MonthlyEvolution[]>([])
  const [categorySpending, setCategorySpending] = useState<CategorySpending[]>([])
  const [insights, setInsights] = useState<FinancialInsight[]>([])
  const [isLoading, setIsLoading] = useState(false)

  const fetchDashboard = useCallback(async () => {
    if (!user) return
    setIsLoading(true)
    try {
      const now = new Date()
      const { start, end } = getCurrentMonthRange()

      // Current & previous month stats in parallel
      const prevMonth = now.getMonth() === 0 ? 12 : now.getMonth()
      const prevYear = now.getMonth() === 0 ? now.getFullYear() - 1 : now.getFullYear()

      const [current, prev, accounts, catSpending] = await Promise.all([
        getMonthlyStats(user.user_id, now.getMonth() + 1, now.getFullYear()),
        getMonthlyStats(user.user_id, prevMonth, prevYear),
        getAccountsService(user.user_id),
        getCategorySpending(user.user_id, start, end),
      ])

      const totalBalance = accounts
        .filter((a) => a.type !== 'credit_card')
        .reduce((s, a) => s + a.balance, 0)

      setSummary({
        total_balance: totalBalance,
        monthly_income: current.income,
        monthly_expenses: current.expenses,
        monthly_savings: current.savings,
        savings_rate: current.income > 0
          ? (current.savings / current.income) * 100
          : 0,
      })

      // 6-month evolution (sequential to avoid rate limits)
      const months: MonthlyEvolution[] = []
      for (let i = 5; i >= 0; i--) {
        const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
        const stats = await getMonthlyStats(user.user_id, d.getMonth() + 1, d.getFullYear())
        months.push({
          month: d.toLocaleDateString('pt-BR', { month: 'short', year: '2-digit' }),
          ...stats,
        })
      }
      setEvolution(months)

      // Category spending with percentages
      const totalExp = catSpending.reduce((s, c) => s + c.amount, 0)
      setCategorySpending(
        catSpending.map((c) => ({
          ...c,
          percentage: totalExp > 0 ? (c.amount / totalExp) * 100 : 0,
        }))
      )

      setInsights(generateInsights(current.expenses, prev.expenses, current.income, []))
    } finally {
      setIsLoading(false)
    }
  }, [user])

  useEffect(() => { fetchDashboard() }, [fetchDashboard])

  return { summary, evolution, categorySpending, insights, isLoading, refetch: fetchDashboard }
}

// ============================================================
// useLocalStorage
// ============================================================
export function useLocalStorage<T>(key: string, initialValue: T) {
  const [storedValue, setStoredValue] = useState<T>(() => {
    if (typeof window === 'undefined') return initialValue
    try {
      const item = window.localStorage.getItem(key)
      return item ? JSON.parse(item) : initialValue
    } catch {
      return initialValue
    }
  })

  const setValue = (value: T | ((val: T) => T)) => {
    try {
      const valueToStore = value instanceof Function ? value(storedValue) : value
      setStoredValue(valueToStore)
      if (typeof window !== 'undefined') {
        window.localStorage.setItem(key, JSON.stringify(valueToStore))
      }
    } catch (error) {
      console.error(error)
    }
  }

  return [storedValue, setValue] as const
}
