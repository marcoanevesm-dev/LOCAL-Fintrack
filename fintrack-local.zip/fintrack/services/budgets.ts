import { createClient } from '@/lib/supabase'
import type { Budget, BudgetFormData } from '@/types'

export async function getBudgets(
  userId: string,
  month: number,
  year: number
): Promise<Budget[]> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('budgets')
    .select(`*, category:categories(id, name, color, icon, type)`)
    .eq('user_id', userId)
    .eq('month', month)
    .eq('year', year)

  if (error) throw error

  // Calculate spent amounts for each budget
  const startDate = `${year}-${String(month).padStart(2, '0')}-01`
  const endDate = new Date(year, month, 0).toISOString().split('T')[0]

  const { data: transactions } = await supabase
    .from('transactions')
    .select('category_id, amount')
    .eq('user_id', userId)
    .eq('type', 'expense')
    .eq('status', 'completed')
    .gte('date', startDate)
    .lte('date', endDate)

  const spentByCategory: Record<string, number> = {}
  ;(transactions || []).forEach((t: { category_id: string; amount: number }) => {
    spentByCategory[t.category_id] = (spentByCategory[t.category_id] || 0) + t.amount
  })

  return ((data as Budget[]) || []).map((b) => ({
    ...b,
    spent: spentByCategory[b.category_id] || 0,
  }))
}

export async function createBudget(
  userId: string,
  formData: BudgetFormData
): Promise<Budget> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('budgets')
    .insert({ user_id: userId, ...formData })
    .select(`*, category:categories(id, name, color, icon, type)`)
    .single()

  if (error) throw error
  return { ...(data as Budget), spent: 0 }
}

export async function updateBudget(
  id: string,
  userId: string,
  updates: Partial<BudgetFormData>
): Promise<Budget> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('budgets')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .eq('user_id', userId)
    .select(`*, category:categories(id, name, color, icon, type)`)
    .single()

  if (error) throw error
  return data as Budget
}

export async function deleteBudget(id: string, userId: string): Promise<void> {
  const supabase = createClient()
  const { error } = await supabase
    .from('budgets')
    .delete()
    .eq('id', id)
    .eq('user_id', userId)

  if (error) throw error
}
