import { createClient } from '@/lib/supabase'
import type { Transaction, TransactionFormData, TransactionFilters } from '@/types'

export async function getTransactions(
  userId: string,
  filters: TransactionFilters = {}
): Promise<Transaction[]> {
  const supabase = createClient()
  let query = supabase
    .from('transactions')
    .select(`
      *,
      account:accounts(id, name, color, icon, type),
      category:categories(id, name, color, icon, type)
    `)
    .eq('user_id', userId)
    .order('date', { ascending: false })
    .order('created_at', { ascending: false })

  if (filters.type) query = query.eq('type', filters.type)
  if (filters.category_id) query = query.eq('category_id', filters.category_id)
  if (filters.account_id) query = query.eq('account_id', filters.account_id)
  if (filters.start_date) query = query.gte('date', filters.start_date)
  if (filters.end_date) query = query.lte('date', filters.end_date)
  if (filters.status) query = query.eq('status', filters.status)
  if (filters.min_amount) query = query.gte('amount', filters.min_amount)
  if (filters.max_amount) query = query.lte('amount', filters.max_amount)
  if (filters.search) {
    query = query.ilike('description', `%${filters.search}%`)
  }

  const { data, error } = await query
  if (error) throw error
  return (data as Transaction[]) || []
}

export async function createTransaction(
  userId: string,
  data: TransactionFormData
): Promise<Transaction> {
  const supabase = createClient()

  if (data.installments && data.installments > 1) {
    return createInstallmentTransactions(userId, data)
  }

  const { data: transaction, error } = await supabase
    .from('transactions')
    .insert({
      user_id: userId,
      account_id: data.account_id,
      category_id: data.category_id,
      type: data.type,
      amount: data.amount,
      description: data.description,
      date: data.date,
      status: 'completed',
      payment_method: data.payment_method,
      notes: data.notes,
      is_recurring: data.is_recurring || false,
    })
    .select(`*, account:accounts(*), category:categories(*)`)
    .single()

  if (error) throw error

  // Update account balance
  await updateAccountBalance(userId, data.account_id, data.amount, data.type)

  return transaction as Transaction
}

async function createInstallmentTransactions(
  userId: string,
  data: TransactionFormData
): Promise<Transaction> {
  const supabase = createClient()
  const installments = data.installments!
  const installmentAmount = data.amount / installments
  const installmentId = crypto.randomUUID()
  const transactions = []

  for (let i = 1; i <= installments; i++) {
    const date = new Date(data.date)
    date.setMonth(date.getMonth() + (i - 1))

    transactions.push({
      user_id: userId,
      account_id: data.account_id,
      category_id: data.category_id,
      type: data.type,
      amount: parseFloat(installmentAmount.toFixed(2)),
      description: `${data.description} (${i}/${installments})`,
      date: date.toISOString().split('T')[0],
      status: i === 1 ? 'completed' : 'pending',
      payment_method: data.payment_method,
      notes: data.notes,
      is_recurring: false,
      installment_id: installmentId,
      installment_number: i,
      installment_total: installments,
    })
  }

  const { data: created, error } = await supabase
    .from('transactions')
    .insert(transactions)
    .select(`*, account:accounts(*), category:categories(*)`)

  if (error) throw error

  // Update balance for first installment only
  await updateAccountBalance(userId, data.account_id, installmentAmount, data.type)

  return (created as Transaction[])[0]
}

export async function updateTransaction(
  id: string,
  userId: string,
  updates: Partial<TransactionFormData>
): Promise<Transaction> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('transactions')
    .update({
      ...updates,
      updated_at: new Date().toISOString(),
    })
    .eq('id', id)
    .eq('user_id', userId)
    .select(`*, account:accounts(*), category:categories(*)`)
    .single()

  if (error) throw error
  return data as Transaction
}

export async function deleteTransaction(id: string, userId: string): Promise<void> {
  const supabase = createClient()
  const { data: tx } = await supabase
    .from('transactions')
    .select('amount, type, account_id, status')
    .eq('id', id)
    .eq('user_id', userId)
    .single()

  const { error } = await supabase
    .from('transactions')
    .delete()
    .eq('id', id)
    .eq('user_id', userId)

  if (error) throw error

  // Reverse balance change
  if (tx && tx.status === 'completed') {
    const reverseType = tx.type === 'income' ? 'expense' : 'income'
    await updateAccountBalance(userId, tx.account_id, tx.amount, reverseType as 'income' | 'expense')
  }
}

async function updateAccountBalance(
  userId: string,
  accountId: string,
  amount: number,
  type: 'income' | 'expense' | 'transfer'
): Promise<void> {
  const supabase = createClient()
  const { data: account } = await supabase
    .from('accounts')
    .select('balance')
    .eq('id', accountId)
    .eq('user_id', userId)
    .single()

  if (!account) return

  const delta = type === 'income' ? amount : -amount
  await supabase
    .from('accounts')
    .update({ balance: account.balance + delta })
    .eq('id', accountId)
    .eq('user_id', userId)
}

export async function getMonthlyStats(
  userId: string,
  month: number,
  year: number
): Promise<{ income: number; expenses: number; savings: number }> {
  const supabase = createClient()
  const startDate = `${year}-${String(month).padStart(2, '0')}-01`
  const endDate = new Date(year, month, 0).toISOString().split('T')[0]

  const { data, error } = await supabase
    .from('transactions')
    .select('type, amount')
    .eq('user_id', userId)
    .eq('status', 'completed')
    .gte('date', startDate)
    .lte('date', endDate)

  if (error) throw error

  const rows = (data || []) as { type: string; amount: number }[]

  const income = rows
    .filter((t) => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0)

  const expenses = rows
    .filter((t) => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0)

  return { income, expenses, savings: income - expenses }
}

export async function getCategorySpending(
  userId: string,
  startDate: string,
  endDate: string
): Promise<Array<{ category_id: string; category_name: string; color: string; amount: number }>> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('transactions')
    .select(`amount, category:categories(id, name, color)`)
    .eq('user_id', userId)
    .eq('type', 'expense')
    .eq('status', 'completed')
    .gte('date', startDate)
    .lte('date', endDate)

  if (error) throw error

  const grouped: Record<string, { name: string; color: string; amount: number }> = {}
  ;(data || []).forEach((t: any) => {
    if (!t.category) return
    const key = t.category.id
    if (!grouped[key]) {
      grouped[key] = { name: t.category.name, color: t.category.color, amount: 0 }
    }
    grouped[key].amount += t.amount
  })

  return Object.entries(grouped).map(([id, v]) => ({
    category_id: id,
    category_name: v.name,
    color: v.color,
    amount: v.amount,
  }))
}
