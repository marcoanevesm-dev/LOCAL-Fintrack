import { createClient } from '@/lib/supabase'
import type { CreditCard, CreditCardFormData } from '@/types'

export async function getCreditCards(userId: string): Promise<CreditCard[]> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('credit_cards')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: true })

  if (error) throw error
  return (data as CreditCard[]) || []
}

export async function createCreditCard(
  userId: string,
  formData: CreditCardFormData
): Promise<CreditCard> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('credit_cards')
    .insert({
      user_id: userId,
      name: formData.name,
      bank_name: formData.bank_name,
      limit_amount: formData.limit_amount,
      closing_day: formData.closing_day,
      due_day: formData.due_day,
      color: formData.color,
      last_four_digits: formData.last_four_digits || null,
    })
    .select()
    .single()

  if (error) throw error
  return data as CreditCard
}

export async function updateCreditCard(
  id: string,
  userId: string,
  formData: Partial<CreditCardFormData>
): Promise<CreditCard> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('credit_cards')
    .update({
      name: formData.name,
      bank_name: formData.bank_name,
      limit_amount: formData.limit_amount,
      closing_day: formData.closing_day,
      due_day: formData.due_day,
      color: formData.color,
      last_four_digits: formData.last_four_digits || null,
      updated_at: new Date().toISOString(),
    })
    .eq('id', id)
    .eq('user_id', userId)
    .select()
    .single()

  if (error) throw error
  return data as CreditCard
}

export async function deleteCreditCard(id: string, userId: string): Promise<void> {
  const supabase = createClient()
  const { error } = await supabase
    .from('credit_cards')
    .delete()
    .eq('id', id)
    .eq('user_id', userId)

  if (error) throw error
}

/**
 * Returns the total spent on a card in the current billing cycle.
 * The cycle runs from (closing_day + 1) last month → closing_day this month.
 */
export async function getCardBillAmount(
  userId: string,
  closingDay: number
): Promise<number> {
  const supabase = createClient()
  const now = new Date()

  // Compute cycle end date
  const cycleEnd = new Date(now.getFullYear(), now.getMonth(), closingDay)
  if (now.getDate() > closingDay) {
    cycleEnd.setMonth(cycleEnd.getMonth() + 1)
  }

  // Cycle start is the day after closing_day in the previous month
  const cycleStart = new Date(cycleEnd)
  cycleStart.setMonth(cycleStart.getMonth() - 1)
  cycleStart.setDate(closingDay + 1)

  const fmt = (d: Date) => d.toISOString().split('T')[0]

  const { data, error } = await supabase
    .from('transactions')
    .select('amount')
    .eq('user_id', userId)
    .eq('payment_method', 'credit')
    .eq('type', 'expense')
    .gte('date', fmt(cycleStart))
    .lte('date', fmt(cycleEnd))

  if (error) throw error
  return (data || []).reduce((sum: number, t: { amount: number }) => sum + t.amount, 0)
}
