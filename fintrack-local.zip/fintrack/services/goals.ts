import { createClient } from '@/lib/supabase'
import type { Goal, GoalFormData } from '@/types'

export async function getGoals(userId: string): Promise<Goal[]> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('goals')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })

  if (error) throw error
  return (data as Goal[]) || []
}

export async function createGoal(userId: string, formData: GoalFormData): Promise<Goal> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('goals')
    .insert({ user_id: userId, ...formData, status: 'active' })
    .select()
    .single()

  if (error) throw error
  return data as Goal
}

export async function updateGoal(
  id: string,
  userId: string,
  updates: Partial<GoalFormData>
): Promise<Goal> {
  const supabase = createClient()
  const updateData = { ...updates, updated_at: new Date().toISOString() } as Partial<Goal>

  // Auto-complete if target reached
  if (updates.current_amount !== undefined && updates.target_amount !== undefined) {
    if (updates.current_amount >= updates.target_amount) {
      updateData.status = 'completed'
    }
  }

  const { data, error } = await supabase
    .from('goals')
    .update(updateData)
    .eq('id', id)
    .eq('user_id', userId)
    .select()
    .single()

  if (error) throw error
  return data as Goal
}

export async function addGoalContribution(
  id: string,
  userId: string,
  amount: number
): Promise<Goal> {
  const supabase = createClient()
  const { data: goal } = await supabase
    .from('goals')
    .select('current_amount, target_amount')
    .eq('id', id)
    .eq('user_id', userId)
    .single()

  if (!goal) throw new Error('Goal not found')

  const newAmount = Math.min(goal.current_amount + amount, goal.target_amount)
  const status = newAmount >= goal.target_amount ? 'completed' : 'active'

  return updateGoal(id, userId, { current_amount: newAmount } as GoalFormData)
}

export async function deleteGoal(id: string, userId: string): Promise<void> {
  const supabase = createClient()
  const { error } = await supabase
    .from('goals')
    .delete()
    .eq('id', id)
    .eq('user_id', userId)

  if (error) throw error
}
