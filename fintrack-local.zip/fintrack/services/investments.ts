import { createClient } from '@/lib/supabase'
import type { Investment } from '@/types'

export async function getInvestments(userId: string): Promise<Investment[]> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('investments')
    .select('*')
    .eq('user_id', userId)
    .order('invested_amount', { ascending: false })

  if (error) throw error
  return (data as Investment[]) || []
}

export async function createInvestment(
  userId: string,
  formData: Omit<Investment, 'id' | 'user_id' | 'created_at' | 'updated_at'>
): Promise<Investment> {
  const supabase = createClient()
  const currentValue = formData.quantity * formData.current_price
  const profitability = formData.invested_amount > 0
    ? ((currentValue - formData.invested_amount) / formData.invested_amount) * 100
    : 0

  const { data, error } = await supabase
    .from('investments')
    .insert({
      user_id: userId,
      ...formData,
      current_value: currentValue,
      profitability,
    })
    .select()
    .single()

  if (error) throw error
  return data as Investment
}

export async function updateInvestment(
  id: string,
  userId: string,
  updates: Partial<Investment>
): Promise<Investment> {
  const supabase = createClient()

  if (updates.quantity !== undefined && updates.current_price !== undefined) {
    updates.current_value = updates.quantity * updates.current_price
  }
  if (updates.current_value !== undefined && updates.invested_amount !== undefined) {
    updates.profitability =
      ((updates.current_value - updates.invested_amount) / updates.invested_amount) * 100
  }

  const { data, error } = await supabase
    .from('investments')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .eq('user_id', userId)
    .select()
    .single()

  if (error) throw error
  return data as Investment
}

export async function deleteInvestment(id: string, userId: string): Promise<void> {
  const supabase = createClient()
  const { error } = await supabase
    .from('investments')
    .delete()
    .eq('id', id)
    .eq('user_id', userId)

  if (error) throw error
}

export function getInvestmentSummary(investments: Investment[]) {
  const total = investments.reduce((s, i) => s + i.current_value, 0)
  const invested = investments.reduce((s, i) => s + i.invested_amount, 0)
  const profit = total - invested
  const profitability = invested > 0 ? (profit / invested) * 100 : 0

  const byType = investments.reduce(
    (acc, inv) => {
      acc[inv.type] = (acc[inv.type] || 0) + inv.current_value
      return acc
    },
    {} as Record<string, number>
  )

  return { total, invested, profit, profitability, byType }
}
