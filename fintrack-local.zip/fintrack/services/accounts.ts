import { createClient } from '@/lib/supabase'
import type { Account, AccountFormData } from '@/types'

export async function getAccounts(userId: string): Promise<Account[]> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('accounts')
    .select('*')
    .eq('user_id', userId)
    .eq('is_active', true)
    .order('created_at', { ascending: true })

  if (error) throw error
  return (data as Account[]) || []
}

export async function createAccount(
  userId: string,
  formData: AccountFormData
): Promise<Account> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('accounts')
    .insert({ user_id: userId, ...formData })
    .select()
    .single()

  if (error) throw error
  return data as Account
}

export async function updateAccount(
  id: string,
  userId: string,
  updates: Partial<AccountFormData>
): Promise<Account> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('accounts')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .eq('user_id', userId)
    .select()
    .single()

  if (error) throw error
  return data as Account
}

export async function deleteAccount(id: string, userId: string): Promise<void> {
  const supabase = createClient()
  const { error } = await supabase
    .from('accounts')
    .update({ is_active: false })
    .eq('id', id)
    .eq('user_id', userId)

  if (error) throw error
}

export function getTotalBalance(accounts: Account[]): number {
  return accounts
    .filter((a) => a.type !== 'credit_card')
    .reduce((sum, a) => sum + a.balance, 0)
}
