import { createClient } from '@/lib/supabase'
import type { Category, CategoryFormData } from '@/types'

const DEFAULT_CATEGORIES = [
  // Expense
  { name: 'Alimentação', type: 'expense', color: '#f97316', icon: 'utensils', is_default: true },
  { name: 'Transporte', type: 'expense', color: '#0ea5e9', icon: 'car', is_default: true },
  { name: 'Saúde', type: 'expense', color: '#ef4444', icon: 'heart-pulse', is_default: true },
  { name: 'Moradia', type: 'expense', color: '#84cc16', icon: 'home', is_default: true },
  { name: 'Educação', type: 'expense', color: '#6366f1', icon: 'graduation-cap', is_default: true },
  { name: 'Lazer', type: 'expense', color: '#a855f7', icon: 'gamepad-2', is_default: true },
  { name: 'Assinaturas', type: 'expense', color: '#14b8a6', icon: 'monitor', is_default: true },
  { name: 'Vestuário', type: 'expense', color: '#ec4899', icon: 'shirt', is_default: true },
  { name: 'Outros', type: 'expense', color: '#64748b', icon: 'tag', is_default: true },
  // Income
  { name: 'Salário', type: 'income', color: '#10b981', icon: 'briefcase', is_default: true },
  { name: 'Freelance', type: 'income', color: '#06b6d4', icon: 'laptop', is_default: true },
  { name: 'Investimentos', type: 'income', color: '#6366f1', icon: 'trending-up', is_default: true },
  { name: 'Outros', type: 'income', color: '#64748b', icon: 'plus-circle', is_default: true },
]

export async function getCategories(userId: string): Promise<Category[]> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('categories')
    .select('*')
    .eq('user_id', userId)
    .order('name', { ascending: true })

  if (error) throw error
  return (data as Category[]) || []
}

export async function createCategory(
  userId: string,
  formData: CategoryFormData
): Promise<Category> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('categories')
    .insert({ user_id: userId, ...formData, is_default: false })
    .select()
    .single()

  if (error) throw error
  return data as Category
}

export async function updateCategory(
  id: string,
  userId: string,
  updates: Partial<CategoryFormData>
): Promise<Category> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('categories')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', id)
    .eq('user_id', userId)
    .select()
    .single()

  if (error) throw error
  return data as Category
}

export async function deleteCategory(id: string, userId: string): Promise<void> {
  const supabase = createClient()
  const { error } = await supabase
    .from('categories')
    .delete()
    .eq('id', id)
    .eq('user_id', userId)
    .eq('is_default', false)

  if (error) throw error
}

export async function seedDefaultCategories(userId: string): Promise<void> {
  const supabase = createClient()
  const { data: existing } = await supabase
    .from('categories')
    .select('id')
    .eq('user_id', userId)
    .limit(1)

  if (existing && existing.length > 0) return // already seeded

  const toInsert = DEFAULT_CATEGORIES.map((c) => ({ ...c, user_id: userId }))
  const { error } = await supabase.from('categories').insert(toInsert)
  if (error) throw error
}
